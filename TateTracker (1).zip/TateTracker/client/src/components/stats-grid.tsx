import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { 
  CheckSquareIcon, 
  CalendarCheckIcon, 
  FlameIcon, 
  TrophyIcon 
} from "lucide-react";
import { calculateCompletedTasks } from "@/lib/utils";
import { Task, Habit } from "@shared/schema";

const StatCard = ({ 
  icon, 
  label, 
  value, 
  total, 
  suffix, 
  color 
}: { 
  icon: React.ReactNode, 
  label: string, 
  value: number | string, 
  total?: number, 
  suffix?: string,
  color: "primary" | "accent" 
}) => {
  return (
    <Card className="bg-secondary">
      <CardContent className="p-4 flex items-center">
        <div className={`w-12 h-12 bg-${color}/20 rounded-lg flex items-center justify-center mr-4`}>
          {icon}
        </div>
        <div>
          <p className="text-sm text-muted-foreground">{label}</p>
          <p className="text-2xl font-bold">
            {value}
            {total ? <span className="text-sm text-muted-foreground font-normal">/{total}</span> : null}
            {suffix ? <span className="text-sm text-accent font-normal"> {suffix}</span> : null}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

const StatsGrid = () => {
  // Fetch tasks
  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ['/api/tasks']
  });
  
  // Fetch habits
  const { data: habits = [] } = useQuery<Habit[]>({
    queryKey: ['/api/habits']
  });
  
  // Fetch user for streak and level
  const { data: user } = useQuery({
    queryKey: ['/api/user']
  });
  
  // Calculate stats
  const { completed: completedTasks, total: totalTasks } = calculateCompletedTasks(tasks);
  const totalHabits = habits.length;
  const trackedHabits = habits.filter(habit => habit.streak > 0).length;
  const currentStreak = user?.currentStreak || 0;
  const level = user?.level || 1;
  const levelProgress = user?.levelProgress || 0;
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      <StatCard
        icon={<CheckSquareIcon className="text-primary h-6 w-6" />}
        label="Tasks Completed"
        value={completedTasks}
        total={totalTasks}
        color="primary"
      />
      
      <StatCard
        icon={<CalendarCheckIcon className="text-accent h-6 w-6" />}
        label="Habits Tracked"
        value={trackedHabits}
        total={totalHabits}
        color="accent"
      />
      
      <StatCard
        icon={<FlameIcon className="text-accent h-6 w-6" />}
        label="Current Streak"
        value={currentStreak}
        suffix="days"
        color="accent"
      />
      
      <Card className="bg-secondary">
        <CardContent className="p-4 flex items-center">
          <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mr-4">
            <TrophyIcon className="text-primary h-6 w-6" />
          </div>
          <div className="w-full">
            <p className="text-sm text-muted-foreground">Level Progress</p>
            <Progress 
              value={levelProgress} 
              className="h-2 bg-muted mt-2 w-full"
              indicatorClassName="bg-gradient-to-r from-primary to-accent" 
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StatsGrid;
