import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useRandomQuote } from "@/hooks/use-quotes";
import { 
  ListChecks, 
  LayoutDashboardIcon, 
  CalendarCheckIcon, 
  ClockIcon, 
  BarChart2Icon, 
  BellIcon,
  MenuIcon,
  VideoIcon,
  ShieldIcon,
  Instagram,
  Trophy
} from "lucide-react";
import knightLogo from '../assets/knight-logo.png';

const Sidebar = () => {
  const [location] = useLocation();
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const { toast } = useToast();
  const { quote } = useRandomQuote();
  
  // Get user (in a real app this would include auth)
  const { data: user } = useQuery({
    queryKey: ['/api/user']
  });

  // Close sidebar on route change for mobile
  useEffect(() => {
    setIsMobileSidebarOpen(false);
  }, [location]);

  // Close sidebar when clicking outside on mobile
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const sidebar = document.getElementById('sidebar');
      const sidebarToggle = document.getElementById('sidebar-toggle');
      
      if (
        isMobileSidebarOpen &&
        sidebar &&
        !sidebar.contains(event.target as Node) &&
        sidebarToggle &&
        !sidebarToggle.contains(event.target as Node)
      ) {
        setIsMobileSidebarOpen(false);
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, [isMobileSidebarOpen]);

  const toggleMobileSidebar = () => {
    setIsMobileSidebarOpen(!isMobileSidebarOpen);
  };

  const isActiveRoute = (path: string) => {
    return location === path;
  };

  return (
    <>
      {/* Mobile sidebar toggle button */}
      <button
        id="sidebar-toggle"
        className="md:hidden fixed top-4 left-4 z-40 bg-secondary p-2 rounded-md"
        onClick={toggleMobileSidebar}
      >
        <MenuIcon className="h-5 w-5" />
      </button>

      {/* Sidebar */}
      <div
        id="sidebar"
        className={`${
          isMobileSidebarOpen ? 'fixed inset-0 z-30' : 'hidden'
        } md:relative md:flex md:w-64 flex-col bg-secondary p-4 h-full overflow-y-auto transition-all duration-300`}
      >
        <div className="flex items-center mb-8">
          <div className="w-12 h-12 flex items-center justify-center">
            <img src={knightLogo} alt="Knight Logo" className="w-full h-full object-contain" />
          </div>
          <h1 className="text-xl ml-3 font-montserrat font-extrabold text-accent">
            TOP G <span className="text-white">TASKS</span>
          </h1>
        </div>

        <nav className="space-y-2">
          <Link href="/">
            <a
              className={`flex items-center p-3 rounded-lg ${
                isActiveRoute('/')
                  ? 'bg-primary text-white'
                  : 'hover:bg-muted transition-all'
              }`}
            >
              <LayoutDashboardIcon className="mr-3 h-5 w-5" />
              <span className="font-medium">Dashboard</span>
            </a>
          </Link>
          
          <Link href="/tasks">
            <a
              className={`flex items-center p-3 rounded-lg ${
                isActiveRoute('/tasks')
                  ? 'bg-primary text-white'
                  : 'hover:bg-muted transition-all'
              }`}
            >
              <ListChecks className="mr-3 h-5 w-5" />
              <span className="font-medium">Tasks</span>
            </a>
          </Link>
          
          <Link href="/habits">
            <a
              className={`flex items-center p-3 rounded-lg ${
                isActiveRoute('/habits')
                  ? 'bg-primary text-white'
                  : 'hover:bg-muted transition-all'
              }`}
            >
              <CalendarCheckIcon className="mr-3 h-5 w-5" />
              <span className="font-medium">Habits</span>
            </a>
          </Link>
          
          <Link href="/routine">
            <a
              className={`flex items-center p-3 rounded-lg ${
                isActiveRoute('/routine')
                  ? 'bg-primary text-white'
                  : 'hover:bg-muted transition-all'
              }`}
            >
              <ClockIcon className="mr-3 h-5 w-5" />
              <span className="font-medium">Daily Routine</span>
            </a>
          </Link>
          
          <Link href="/progress">
            <a
              className={`flex items-center p-3 rounded-lg ${
                isActiveRoute('/progress')
                  ? 'bg-primary text-white'
                  : 'hover:bg-muted transition-all'
              }`}
            >
              <BarChart2Icon className="mr-3 h-5 w-5" />
              <span className="font-medium">Progress</span>
            </a>
          </Link>
          
          <Link href="/videos">
            <a
              className={`flex items-center p-3 rounded-lg ${
                isActiveRoute('/videos')
                  ? 'bg-primary text-white'
                  : 'hover:bg-muted transition-all'
              }`}
            >
              <VideoIcon className="mr-3 h-5 w-5" />
              <span className="font-medium">Tate Videos</span>
            </a>
          </Link>
          
          <Link href="/tate-shorts">
            <a
              className={`flex items-center p-3 rounded-lg ${
                isActiveRoute('/tate-shorts')
                  ? 'bg-primary text-white'
                  : 'hover:bg-muted transition-all'
              }`}
            >
              <Instagram className="mr-3 h-5 w-5" />
              <span className="font-medium">Tate Shorts</span>
              <span className="ml-auto bg-accent text-xs px-1.5 py-0.5 rounded-full">New</span>
            </a>
          </Link>
          
          <Link href="/notifications">
            <a
              className={`flex items-center p-3 rounded-lg ${
                isActiveRoute('/notifications')
                  ? 'bg-primary text-white'
                  : 'hover:bg-muted transition-all'
              }`}
            >
              <BellIcon className="mr-3 h-5 w-5" />
              <span className="font-medium">Notifications</span>
            </a>
          </Link>
          
          <Link href="/challenges">
            <a
              className={`flex items-center p-3 rounded-lg ${
                isActiveRoute('/challenges')
                  ? 'bg-primary text-white'
                  : 'hover:bg-muted transition-all'
              }`}
            >
              <Trophy className="mr-3 h-5 w-5" />
              <span className="font-medium">Challenges</span>
              <span className="ml-auto bg-accent text-xs px-1.5 py-0.5 rounded-full">New</span>
            </a>
          </Link>
          
          <Link href="/admin">
            <a
              className={`flex items-center p-3 rounded-lg ${
                isActiveRoute('/admin')
                  ? 'bg-primary text-white'
                  : 'hover:bg-muted transition-all'
              }`}
            >
              <ShieldIcon className="mr-3 h-5 w-5" />
              <span className="font-medium">Admin Panel</span>
            </a>
          </Link>
        </nav>

        <div className="mt-auto pt-6">
          <div className="quote-card p-4 rounded-lg">
            <p className="text-sm text-accent italic mb-2">
              {quote?.text || "The temporary satisfaction of quitting is outweighed by the eternal suffering of being a nobody."}
            </p>
            <p className="text-xs text-right">- {quote?.author || "Andrew Tate"}</p>
          </div>

          <div className="bg-muted rounded-lg p-4 mt-4">
            <div className="flex items-center">
              <Avatar>
                <AvatarFallback className="p-0 overflow-hidden">
                  <img src={knightLogo} alt="Knight Logo" className="w-full h-full object-cover" />
                </AvatarFallback>
              </Avatar>
              <div className="ml-3">
                <p className="font-medium">True Believer</p>
                <p className="text-xs text-muted-foreground">
                  Level {user?.level || 1} Top G
                </p>
              </div>
              <button className="ml-auto text-sm bg-secondary rounded-md p-1">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-4 w-4"
                >
                  <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path>
                  <circle cx="12" cy="12" r="3"></circle>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
