import React from "react";
import { PremiumRoutine } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import LockedRoutine from "./locked-routine";
import { Dumbbell } from "lucide-react";

const PremiumRoutinesList = () => {
  const { data: premiumRoutines = [], isLoading, error } = useQuery({
    queryKey: ['/api/premium-routines'],
    queryFn: getQueryFn({ on401: "returnNull" })
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <Dumbbell className="animate-pulse h-8 w-8 mx-auto mb-4 text-red-500" />
          <p className="text-white">Loading premium routines...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center p-8 text-red-500">
        <p>Error loading routines. Please try again later.</p>
      </div>
    );
  }

  if (premiumRoutines.length === 0) {
    return (
      <div className="text-center p-8 text-gray-400">
        <p>No premium routines available at this time.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
      {premiumRoutines.map((routine: PremiumRoutine) => (
        <LockedRoutine key={routine.id} premiumRoutine={routine} />
      ))}
    </div>
  );
};

export default PremiumRoutinesList;