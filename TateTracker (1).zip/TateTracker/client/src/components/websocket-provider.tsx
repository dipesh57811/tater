import { createContext, useContext, ReactNode, useEffect, useState } from 'react';
import { useWebSocket, WebSocketMessage } from '@/hooks/use-websocket';
import { useToast } from '@/hooks/use-toast';
import { getRandomTateQuote } from '@/lib/quotes-service';

interface WebSocketContextType {
  isConnected: boolean;
  messages: WebSocketMessage[];
  notifications: WebSocketMessage[];
  sendMessage: (message: WebSocketMessage) => void;
  clearNotifications: () => void;
}

const WebSocketContext = createContext<WebSocketContextType | undefined>(undefined);

export function useWebSocketContext() {
  const context = useContext(WebSocketContext);
  if (context === undefined) {
    throw new Error('useWebSocketContext must be used within a WebSocketProvider');
  }
  return context;
}

interface WebSocketProviderProps {
  children: ReactNode;
}

export function WebSocketProvider({ children }: WebSocketProviderProps) {
  const websocket = useWebSocket();
  const { toast } = useToast();
  
  // Keep track of processed messages to avoid showing duplicates
  const [processedMessageIds, setProcessedMessageIds] = useState<string[]>([]);
  
  // Show toast notifications when new messages come in
  useEffect(() => {
    if (websocket.messages.length > 0) {
      const latestMessage = websocket.messages[websocket.messages.length - 1];
      
      // Create a message ID from timestamp and type to track which we've processed
      const messageId = `${latestMessage.type}-${latestMessage.timestamp || new Date().toISOString()}`;
      
      // Only process messages we haven't seen before
      if (!processedMessageIds.includes(messageId)) {
        setProcessedMessageIds((prev: string[]) => [...prev, messageId]);
        
        // Get a random motivational quote for each notification
        const motivationalQuote = getRandomTateQuote();
        
        // Show toast notifications for certain message types
        if (latestMessage.type === 'new_video') {
          toast({
            title: "New Video Available",
            description: (
              <div>
                <p className="mb-2">{latestMessage.title}</p>
                <p className="text-xs text-red-400 italic font-bold">{motivationalQuote}</p>
              </div>
            ),
            variant: "default",
          });
        } else if (latestMessage.type === 'video_liked') {
          toast({
            title: "Your video was liked",
            description: (
              <div>
                <p className="mb-2">{`${latestMessage.title} now has ${latestMessage.likes} likes`}</p>
                <p className="text-xs text-red-400 italic font-bold">{motivationalQuote}</p>
              </div>
            ),
            variant: "default",
          });
        } else if (latestMessage.type === 'video_comment') {
          toast({
            title: "New Comment",
            description: (
              <div>
                <p className="mb-2">{`Someone commented on your video: "${latestMessage.comment?.substring(0, 30)}${latestMessage.comment?.length > 30 ? '...' : ''}"`}</p>
                <p className="text-xs text-red-400 italic font-bold">{motivationalQuote}</p>
              </div>
            ),
            variant: "default",
          });
        } else if (latestMessage.type === 'coins_earned') {
          toast({
            title: "Coins Earned",
            description: (
              <div>
                <p className="mb-2">{`You earned ${latestMessage.coinsEarned} coins from your video`}</p>
                <p className="text-xs text-red-400 italic font-bold">{motivationalQuote}</p>
              </div>
            ),
            variant: "default",
            className: "bg-yellow-500 text-black border-yellow-600",
          });
        } else if (latestMessage.type === 'announcement') {
          // Handle announcement messages
          if (latestMessage.action === 'create') {
            toast({
              title: "New Announcement",
              description: (
                <div>
                  <p className="mb-2">{latestMessage.announcement?.title}</p>
                  <p className="text-xs text-red-400 italic font-bold">{motivationalQuote}</p>
                </div>
              ),
              variant: "default",
            });
          } else if (latestMessage.action === 'update') {
            toast({
              title: "Announcement Updated",
              description: (
                <div>
                  <p className="mb-2">{latestMessage.announcement?.title}</p>
                  <p className="text-xs text-red-400 italic font-bold">{motivationalQuote}</p>
                </div>
              ),
              variant: "default",
            });
          }
        }
      }
    }
    
    // Limit the size of our processed messages array to avoid memory issues
    if (processedMessageIds.length > 100) {
      setProcessedMessageIds((prev: string[]) => prev.slice(-50));
    }
  }, [websocket.messages, toast, processedMessageIds]);
  
  return (
    <WebSocketContext.Provider value={websocket}>
      {children}
    </WebSocketContext.Provider>
  );
}