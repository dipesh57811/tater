import React, { useEffect, useState } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import { format } from 'date-fns';

interface Announcement {
  id: number;
  title: string;
  content: string;
  type: string;
  isActive: boolean;
  isPinned: boolean;
  createdAt: string;
  updatedAt: string;
}

export const AnnouncementBar: React.FC = () => {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(true);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch active announcements
  useEffect(() => {
    const fetchAnnouncements = async () => {
      try {
        const response = await fetch('/api/announcements/active');
        if (response.ok) {
          const data = await response.json();
          
          // Sort pinned announcements first
          const sortedAnnouncements = [...data].sort((a, b) => {
            if (a.isPinned && !b.isPinned) return -1;
            if (!a.isPinned && b.isPinned) return 1;
            return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
          });
          
          setAnnouncements(sortedAnnouncements);
        }
      } catch (error) {
        console.error('Failed to fetch announcements:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchAnnouncements();
  }, []);

  // No announcements or not loaded yet, don't render anything
  if (announcements.length === 0 || isLoading) {
    return null;
  }

  // Not visible, don't render anything
  if (!isVisible) {
    return null;
  }

  const currentAnnouncement = announcements[currentIndex];
  
  // Helper function to get the background color based on type
  const getTypeStyles = (type: string) => {
    switch (type) {
      case 'URGENT':
        return 'bg-red-900 border-red-700';
      case 'UPDATE':
        return 'bg-blue-900 border-blue-700';
      case 'JOB':
        return 'bg-green-900 border-green-700';
      case 'PROMOTION':
        return 'bg-yellow-900 border-yellow-700';
      default:
        return 'bg-gray-800 border-gray-700';
    }
  };

  const handlePrev = () => {
    setCurrentIndex(prev => (prev === 0 ? announcements.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex(prev => (prev === announcements.length - 1 ? 0 : prev + 1));
  };

  const handleDismiss = () => {
    setIsVisible(false);
  };

  return (
    <div className={`relative py-2 px-4 ${getTypeStyles(currentAnnouncement.type)} border-b text-white`}>
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex-1 flex items-center space-x-2">
          {/* Only show navigation if there are multiple announcements */}
          {announcements.length > 1 && (
            <button 
              onClick={handlePrev}
              className="p-1 rounded-full hover:bg-black/20"
              aria-label="Previous announcement"
            >
              <ChevronLeft size={16} />
            </button>
          )}
          
          <div className="flex-1">
            <div className="flex items-center">
              <p className="text-sm font-medium">
                <span className="font-bold">{currentAnnouncement.title}</span>
                {currentAnnouncement.isPinned && (
                  <span className="ml-2 bg-yellow-500 text-black text-xs px-1.5 py-0.5 rounded-full">
                    PINNED
                  </span>
                )}
              </p>
              <span className="mx-2 text-xs text-gray-300">
                {format(new Date(currentAnnouncement.createdAt), 'MMM d, yyyy')}
              </span>
            </div>
            <p className="text-sm text-gray-200">{currentAnnouncement.content}</p>
          </div>
          
          {announcements.length > 1 && (
            <button 
              onClick={handleNext}
              className="p-1 rounded-full hover:bg-black/20"
              aria-label="Next announcement"
            >
              <ChevronRight size={16} />
            </button>
          )}
        </div>
        
        <div className="flex items-center ml-4 space-x-2">
          {announcements.length > 1 && (
            <div className="text-xs text-gray-300">
              {currentIndex + 1}/{announcements.length}
            </div>
          )}
          <button 
            onClick={handleDismiss}
            className="p-1 rounded-full hover:bg-black/20"
            aria-label="Dismiss"
          >
            <X size={16} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default AnnouncementBar;