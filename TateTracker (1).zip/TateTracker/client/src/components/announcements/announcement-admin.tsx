import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Edit, Trash2, Plus, BellRing, Megaphone, MessageCircle, Info } from 'lucide-react';
import { AnnouncementTypes } from '@shared/schema';
import { ToastAction } from '@/components/ui/toast';
import { useWebSocketContext } from '@/components/websocket-provider';

// Define a type for our announcement data
interface Announcement {
  id: number;
  title: string;
  content: string;
  type: string;
  active: boolean;
  expiresAt: Date | null;
  createdAt: Date;
}

// Define schema for form validation
const formSchema = z.object({
  title: z.string().min(3, { message: "Title must be at least 3 characters" }).max(100),
  content: z.string().min(5, { message: "Content must be at least 5 characters" }),
  type: z.enum(["INFO", "WARNING", "UPDATE"]),
  active: z.boolean(),
  expiresAt: z.date().nullable(),
});

type FormValues = z.infer<typeof formSchema>;

export const AnnouncementAdmin: React.FC = () => {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingAnnouncement, setEditingAnnouncement] = useState<Announcement | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const { toast } = useToast();
  const { sendMessage } = useWebSocketContext();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      content: "",
      type: "INFO",
      active: true,
      expiresAt: null
    }
  });

  // Fetch all announcements
  const fetchAnnouncements = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/announcements');
      if (!response.ok) {
        throw new Error('Failed to fetch announcements');
      }
      const data = await response.json();
      // Convert date strings to Date objects
      const processedData = data.map((announcement: any) => ({
        ...announcement,
        createdAt: new Date(announcement.createdAt),
        expiresAt: announcement.expiresAt ? new Date(announcement.expiresAt) : null
      }));
      setAnnouncements(processedData);
    } catch (error) {
      console.error('Error fetching announcements:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load announcements",
      });
    } finally {
      setLoading(false);
    }
  };

  // Initial fetch
  useEffect(() => {
    fetchAnnouncements();
  }, []);

  // Handle form submission for creating/editing announcements
  const onSubmit = async (values: FormValues) => {
    try {
      let response;
      
      if (editingAnnouncement) {
        // Update existing announcement
        response = await fetch(`/api/announcements/${editingAnnouncement.id}`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(values),
        });
      } else {
        // Create new announcement
        response = await fetch('/api/announcements', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(values),
        });
      }

      if (!response.ok) {
        throw new Error('Failed to save announcement');
      }

      const savedAnnouncement = await response.json();
      
      // Send WebSocket notification for new or updated announcement
      sendMessage({
        type: 'announcement',
        action: editingAnnouncement ? 'update' : 'create',
        announcement: savedAnnouncement
      });

      fetchAnnouncements();
      setOpenDialog(false);
      setEditingAnnouncement(null);
      form.reset();
      
      toast({
        title: editingAnnouncement ? "Announcement Updated" : "Announcement Created",
        description: editingAnnouncement 
          ? "Your announcement has been updated successfully." 
          : "Your announcement has been created successfully.",
        action: <ToastAction altText="View">View</ToastAction>,
      });
    } catch (error) {
      console.error('Error saving announcement:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to save announcement",
      });
    }
  };

  // Handle editing an announcement
  const handleEdit = (announcement: Announcement) => {
    setEditingAnnouncement(announcement);
    form.reset({
      title: announcement.title,
      content: announcement.content,
      type: announcement.type as any,
      active: announcement.active,
      expiresAt: announcement.expiresAt
    });
    setOpenDialog(true);
  };

  // Handle deleting an announcement
  const handleDelete = async (id: number) => {
    if (window.confirm('Are you sure you want to delete this announcement?')) {
      try {
        const response = await fetch(`/api/announcements/${id}`, {
          method: 'DELETE',
        });

        if (!response.ok) {
          throw new Error('Failed to delete announcement');
        }

        // Send WebSocket notification for deleted announcement
        sendMessage({
          type: 'announcement',
          action: 'delete',
          announcementId: id
        });

        fetchAnnouncements();
        toast({
          title: "Announcement Deleted",
          description: "The announcement has been deleted successfully.",
        });
      } catch (error) {
        console.error('Error deleting announcement:', error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to delete announcement",
        });
      }
    }
  };

  // Get icon based on announcement type
  const getAnnouncementIcon = (type: string) => {
    switch (type) {
      case 'INFO':
        return <Info className="h-5 w-5 text-blue-500" />;
      case 'WARNING':
        return <BellRing className="h-5 w-5 text-yellow-500" />;
      case 'UPDATE':
        return <Megaphone className="h-5 w-5 text-green-500" />;
      default:
        return <MessageCircle className="h-5 w-5 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-2xl font-bold text-white">Announcements</h3>
        <Dialog open={openDialog} onOpenChange={setOpenDialog}>
          <DialogTrigger asChild>
            <Button 
              onClick={() => {
                setEditingAnnouncement(null);
                form.reset({
                  title: "",
                  content: "",
                  type: "INFO",
                  active: true,
                  expiresAt: null
                });
              }}
              className="bg-red-800 hover:bg-red-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              New Announcement
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-gray-900 border-gray-800">
            <DialogHeader>
              <DialogTitle className="text-xl font-bold">
                {editingAnnouncement ? "Edit Announcement" : "Create New Announcement"}
              </DialogTitle>
              <DialogDescription>
                {editingAnnouncement 
                  ? "Make changes to the existing announcement."
                  : "Fill in the details to create a new announcement."}
              </DialogDescription>
            </DialogHeader>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter announcement title" 
                          {...field} 
                          className="bg-gray-800"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Content</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Enter announcement content" 
                          className="min-h-[100px] bg-gray-800" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Type</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="bg-gray-800">
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-gray-800">
                          <SelectItem value="INFO">Information</SelectItem>
                          <SelectItem value="WARNING">Warning</SelectItem>
                          <SelectItem value="UPDATE">Update</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="active"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                      <div className="space-y-0.5">
                        <FormLabel>Active Status</FormLabel>
                        <FormDescription>
                          Make this announcement visible to users
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button 
                    type="submit" 
                    className="bg-red-800 hover:bg-red-700"
                    disabled={form.formState.isSubmitting}
                  >
                    {form.formState.isSubmitting ? "Saving..." : "Save Announcement"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {loading && <p className="text-center py-4">Loading announcements...</p>}
      
      {!loading && announcements.length === 0 && (
        <Alert className="bg-gray-800 border-gray-700">
          <Info className="h-4 w-4" />
          <AlertTitle>No announcements</AlertTitle>
          <AlertDescription>
            You haven't created any announcements yet. Click the "New Announcement" button to get started.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {announcements.map((announcement) => (
          <Card key={announcement.id} className={`bg-gray-900 border-l-4 ${
            announcement.type === 'WARNING' ? 'border-l-yellow-500' : 
            announcement.type === 'UPDATE' ? 'border-l-green-500' : 
            'border-l-blue-500'
          }`}>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div className="flex items-center">
                  {getAnnouncementIcon(announcement.type)}
                  <CardTitle className="ml-2 text-lg">{announcement.title}</CardTitle>
                </div>
                <div className="flex space-x-2">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleEdit(announcement)}
                    className="h-8 w-8 p-0"
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleDelete(announcement.id)}
                    className="h-8 w-8 p-0 text-red-500 hover:text-red-300"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <CardDescription>
                {format(new Date(announcement.createdAt), 'PPP')}
                {!announcement.active && <span className="ml-2 text-red-500">(Inactive)</span>}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-300 whitespace-pre-line">{announcement.content}</p>
            </CardContent>
            <CardFooter className="pt-0 text-xs text-gray-400">
              {announcement.expiresAt 
                ? `Expires: ${format(new Date(announcement.expiresAt), 'PPP')}`
                : "No expiration date"}
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
};