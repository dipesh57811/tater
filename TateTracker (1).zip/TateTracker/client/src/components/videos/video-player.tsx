import { useEffect, useState } from 'react';
import { Video, VideoComment, insertVideoCommentSchema } from '@shared/schema';
import { formatDate } from '@/lib/utils';
import { Heart, MessageSquare, Share2, ChevronDown, ChevronUp, Send } from 'lucide-react';
import { useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Form, FormControl, FormField, FormItem } from '@/components/ui/form';

interface VideoPlayerProps {
  video: Video;
}

// Comment form schema
const commentFormSchema = insertVideoCommentSchema.pick({
  content: true,
}).extend({
  content: z.string().min(1, "Comment cannot be empty").max(500, "Comment is too long"),
});

type CommentFormValues = z.infer<typeof commentFormSchema>;

export function VideoPlayer({ video }: VideoPlayerProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [earnedCoins, setEarnedCoins] = useState<number | null>(null);
  const [showComments, setShowComments] = useState(false);
  
  // Fetch comments
  const { data: comments = [] } = useQuery({
    queryKey: ['/api/videos', video.id, 'comments'],
    queryFn: async () => {
      const response = await apiRequest(`/api/videos/${video.id}/comments`);
      return response as VideoComment[];
    }
  });
  
  // Initialize form
  const form = useForm<CommentFormValues>({
    resolver: zodResolver(commentFormSchema),
    defaultValues: {
      content: '',
    }
  });
  
  // Like video mutation
  const { mutate: likeVideo } = useMutation({
    mutationFn: async () => {
      return apiRequest(`/api/videos/${video.id}/like`, { method: 'PATCH' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
      queryClient.invalidateQueries({ queryKey: ['/api/videos', video.id] });
      toast({
        title: "Liked!",
        description: "You liked this video",
      });
    }
  });
  
  // Add comment mutation
  const { mutate: addComment, isPending: isAddingComment } = useMutation({
    mutationFn: async (data: CommentFormValues) => {
      return apiRequest(`/api/videos/${video.id}/comments`, {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/videos', video.id, 'comments'] });
      form.reset();
      toast({
        title: "Comment added",
        description: "Your comment was added successfully",
      });
    }
  });
  
  // Earn coins mutation
  const { mutate: earnCoins } = useMutation({
    mutationFn: async () => {
      return apiRequest(`/api/videos/${video.id}/earn`, {
        method: 'POST',
        body: JSON.stringify({ userId: 1 }), // Default user
      });
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      setEarnedCoins(data.coinsEarned);
      toast({
        title: "Coins earned!",
        description: `You earned ${data.coinsEarned} coins for watching this video`,
      });
    }
  });
  
  // When video loads, earn coins after a delay
  useEffect(() => {
    const timer = setTimeout(() => {
      earnCoins();
    }, 5000); // Earn after 5 seconds of watching
    
    return () => clearTimeout(timer);
  }, [earnCoins]);
  
  // Handle form submission
  const onSubmit = (data: CommentFormValues) => {
    addComment(data);
  };
  
  return (
    <div className="space-y-4">
      {/* Video Display */}
      <div className="relative aspect-video bg-black rounded overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-r from-red-900 to-black">
          <div className="text-center">
            <h2 className="text-white text-2xl font-bold mb-4">{video.title}</h2>
            <p className="text-gray-300 text-lg mb-6">Video is loading...</p>
            <Badge className="bg-red-600 text-white text-md px-4 py-2">{video.category}</Badge>
            
            {earnedCoins && (
              <div className="mt-8 bg-black/50 p-4 rounded-md border border-yellow-500">
                <p className="text-yellow-400 font-bold">+ {earnedCoins} COINS EARNED!</p>
                <p className="text-gray-300 text-sm">Keep watching to earn more</p>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Video Info */}
      <div className="bg-black border border-red-900 rounded-md p-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-white text-xl font-bold">{video.title}</h1>
            <p className="text-gray-400 text-sm">{video.views} views • {formatDate(video.createdAt)}</p>
          </div>
          
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="flex items-center bg-red-950/30 border-red-900 hover:bg-red-900 text-white"
              onClick={() => likeVideo()}
            >
              <Heart size={18} className="mr-2 text-red-500" /> {video.likes}
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="flex items-center bg-black border-gray-700 hover:bg-gray-900 text-white"
              onClick={() => setShowComments(!showComments)}
            >
              <MessageSquare size={18} className="mr-2" /> {comments.length}
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="flex items-center bg-black border-gray-700 hover:bg-gray-900 text-white"
            >
              <Share2 size={18} className="mr-2" /> Share
            </Button>
          </div>
        </div>
        
        {/* Video Description */}
        <Accordion type="single" collapsible className="mt-4">
          <AccordionItem value="description" className="border-gray-800">
            <AccordionTrigger className="text-white hover:text-red-500">
              Description
            </AccordionTrigger>
            <AccordionContent className="text-gray-300">
              {video.description}
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
      
      {/* Comments Section */}
      <Card className="bg-black border-red-900">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-white">Comments</CardTitle>
            <CardDescription className="text-gray-400">{comments.length} comments</CardDescription>
          </div>
          <Button 
            variant="ghost" 
            onClick={() => setShowComments(!showComments)}
            className="text-white hover:text-red-500"
          >
            {showComments ? <ChevronUp /> : <ChevronDown />}
          </Button>
        </CardHeader>
        
        {showComments && (
          <>
            <CardContent className="space-y-4">
              {/* Add Comment Form */}
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="flex gap-2">
                  <FormField
                    control={form.control}
                    name="content"
                    render={({ field }) => (
                      <FormItem className="flex-1">
                        <FormControl>
                          <Textarea
                            placeholder="Add a comment..."
                            className="bg-black border-gray-700 text-white focus:border-red-500 resize-none"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <Button 
                    type="submit" 
                    size="sm" 
                    className="self-end bg-red-600 hover:bg-red-700 text-white"
                    disabled={isAddingComment}
                  >
                    <Send size={16} />
                  </Button>
                </form>
              </Form>
              
              {/* Comments List */}
              {comments.length > 0 ? (
                <div className="space-y-4 max-h-80 overflow-y-auto">
                  {comments.map((comment) => (
                    <div key={comment.id} className="border border-gray-800 rounded-md p-3">
                      <div className="flex justify-between mb-1">
                        <h4 className="text-white font-semibold">User #{comment.userId}</h4>
                        <span className="text-gray-500 text-xs">{formatDate(comment.createdAt)}</span>
                      </div>
                      <p className="text-gray-300">{comment.content}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6 text-gray-500">
                  No comments yet. Be the first to comment!
                </div>
              )}
            </CardContent>
            
            <CardFooter className="border-t border-gray-800 pt-4">
              <Button variant="outline" className="w-full bg-black border-gray-700 text-white hover:bg-gray-900">
                Load more comments
              </Button>
            </CardFooter>
          </>
        )}
      </Card>
    </div>
  );
}