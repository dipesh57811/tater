import { Video } from '@shared/schema';
import { formatDate, cn } from '@/lib/utils';
import { Heart, MessageSquare, PlayCircle, Share2 } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'wouter';
import { useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useMutation } from '@tanstack/react-query';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

interface VideoCardProps {
  video: Video;
  variant?: 'default' | 'compact';
}

export function VideoCard({ video, variant = 'default' }: VideoCardProps) {
  const queryClient = useQueryClient();
  
  const { mutate: likeVideo } = useMutation({
    mutationFn: async () => {
      return apiRequest(`/api/videos/${video.id}/like`, { method: 'PATCH' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
      queryClient.invalidateQueries({ queryKey: ['/api/videos', video.id] });
    }
  });
  
  const handleLike = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    likeVideo();
  };
  
  const getThumbnailStyle = () => {
    // Use different background color based on video category
    switch (video.category) {
      case 'TATE_LONG':
        return 'bg-gradient-to-r from-red-900 to-red-700';
      case 'TATE_PODCAST':
        return 'bg-gradient-to-r from-purple-900 to-purple-700';
      case 'TATE_VLOG':
        return 'bg-gradient-to-r from-blue-900 to-blue-700';
      case 'TATE_EDIT':
        return 'bg-gradient-to-r from-orange-900 to-orange-700';
      default:
        return 'bg-gradient-to-r from-gray-900 to-gray-700';
    }
  };
  
  if (variant === 'compact') {
    return (
      <Link to={`/videos/${video.id}`}>
        <Card className="bg-black border-red-900 hover:border-red-600 transition-colors duration-300 overflow-hidden h-full">
          <div className={cn("h-32 flex items-center justify-center relative", getThumbnailStyle())}>
            <PlayCircle size={48} className="text-white/70" />
            <Badge className="absolute top-2 right-2 bg-red-600 text-white">{video.category}</Badge>
          </div>
          <CardHeader className="py-3 px-3">
            <CardTitle className="text-sm font-bold line-clamp-2 text-white">{video.title}</CardTitle>
          </CardHeader>
          <CardFooter className="py-2 px-3 flex justify-between text-xs text-gray-400">
            <div>{formatDate(video.createdAt)}</div>
            <div className="flex items-center space-x-2">
              <span className="flex items-center gap-1">
                <Heart size={12} className="text-red-500" /> {video.likes}
              </span>
              <span className="flex items-center gap-1">
                <MessageSquare size={12} /> {video.commentCount || 0}
              </span>
            </div>
          </CardFooter>
        </Card>
      </Link>
    );
  }
  
  return (
    <Link to={`/videos/${video.id}`}>
      <Card className="bg-black border-red-900 hover:border-red-600 transition-colors duration-300 overflow-hidden h-full">
        <div className={cn("h-48 flex items-center justify-center relative", getThumbnailStyle())}>
          <PlayCircle size={64} className="text-white/70" />
          <Badge className="absolute top-3 right-3 bg-red-600 text-white">{video.category}</Badge>
          <div className="absolute bottom-3 right-3 bg-black/70 px-2 py-1 rounded text-white text-xs">
            {video.duration || '03:45'}
          </div>
        </div>
        <CardHeader className="py-4">
          <CardTitle className="text-white">{video.title}</CardTitle>
          <CardDescription className="text-gray-400">
            {video.views} views • {formatDate(video.createdAt)}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-gray-300 line-clamp-2">{video.description}</p>
        </CardContent>
        <CardFooter className="flex justify-between">
          <div className="flex space-x-2">
            <Button 
              variant="ghost" 
              size="sm" 
              className="flex items-center text-gray-400 hover:text-red-500"
              onClick={handleLike}
            >
              <Heart size={18} className="mr-1" /> {video.likes}
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="flex items-center text-gray-400 hover:text-white"
            >
              <MessageSquare size={18} className="mr-1" /> {video.commentCount || 0}
            </Button>
          </div>
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
            <Share2 size={18} />
          </Button>
        </CardFooter>
      </Card>
    </Link>
  );
}