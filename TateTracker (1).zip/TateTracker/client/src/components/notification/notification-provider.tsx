import React, { createContext, useState, useEffect, useContext, useCallback } from 'react';
import { Bell, X } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { getQueryFn } from '@/lib/queryClient';
import { cn } from '@/lib/utils';
import knightLogo from '../../assets/knight-logo.png';

// Define quote interface for type safety
interface Quote {
  id: number;
  text: string;
  author?: string;
}

// Type definitions
export type NotificationType = 'quote' | 'habit' | 'task';

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  image?: string;
  sound?: string;
  timestamp: Date;
}

interface NotificationContextType {
  notifications: Notification[];
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp'>) => void;
  removeNotification: (id: string) => void;
  clearNotifications: () => void;
  enableHourlyQuotes: boolean;
  setEnableHourlyQuotes: (enable: boolean) => void;
}

// Default knight logo for notifications
const DEFAULT_ICON = knightLogo;

// Create context
const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

// Custom hook to use the notification context
export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};

// Notification Provider component
export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [enableHourlyQuotes, setEnableHourlyQuotes] = useState<boolean>(false);
  
  // Fetch random quote for hourly notifications
  const { refetch: fetchRandomQuote } = useQuery({
    queryKey: ['/api/quotes/random'],
    queryFn: getQueryFn({ on401: 'returnNull' }),
    enabled: false,
  });
  
  // Generate a unique ID for notifications
  const generateId = () => {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  };
  
  // Add a new notification
  const addNotification = useCallback((notification: Omit<Notification, 'id' | 'timestamp'>) => {
    const newNotification: Notification = {
      ...notification,
      id: generateId(),
      timestamp: new Date(),
    };
    
    // Play notification sound if provided
    if (notification.sound) {
      const audio = new Audio(notification.sound);
      audio.play().catch(err => console.error('Error playing notification sound:', err));
    } else {
      // We'll add default sounds later
      console.log('Playing default notification sound');
    }
    
    setNotifications(prev => [newNotification, ...prev]);
    
    // Browser notification if permission is granted
    if ('Notification' in window && Notification.permission === 'granted') {
      const browserNotification = new Notification(notification.title, {
        body: notification.message,
        icon: notification.image || DEFAULT_ICON
      });
      
      browserNotification.onclick = () => {
        window.focus();
      };
    }
  }, []);
  
  // Remove a notification by ID
  const removeNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(notification => notification.id !== id));
  }, []);
  
  // Clear all notifications
  const clearNotifications = useCallback(() => {
    setNotifications([]);
  }, []);
  
  // Request permission for browser notifications on component mount
  useEffect(() => {
    if ('Notification' in window) {
      if (Notification.permission !== 'granted' && Notification.permission !== 'denied') {
        Notification.requestPermission();
      }
    }
  }, []);
  
  // Hourly quote notification
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    const sendQuoteNotification = async () => {
      try {
        const quoteData = await fetchRandomQuote();
        const quote = quoteData.data as Quote;
        
        if (quote && quote.text) {
          addNotification({
            type: 'quote',
            title: 'Top G Wisdom',
            message: quote.text,
            image: knightLogo
          });
        }
      } catch (error) {
        console.error('Error fetching random quote for notification:', error);
      }
    };
    
    if (enableHourlyQuotes) {
      // Initial notification after enabling
      sendQuoteNotification();
      
      // Set up hourly interval
      interval = setInterval(() => {
        sendQuoteNotification();
      }, 60 * 60 * 1000); // 1 hour
      
      // For demo purposes, also send one every minute
      const demoInterval = setInterval(() => {
        sendQuoteNotification();
      }, 60 * 1000); // 1 minute for demo
      
      return () => {
        clearInterval(interval);
        clearInterval(demoInterval);
      };
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [enableHourlyQuotes, fetchRandomQuote, addNotification]);
  
  // Automatically remove notifications after 5 seconds
  useEffect(() => {
    const timeouts: NodeJS.Timeout[] = [];
    
    notifications.forEach(notification => {
      const timeout = setTimeout(() => {
        removeNotification(notification.id);
      }, 5000);
      
      timeouts.push(timeout);
    });
    
    return () => {
      timeouts.forEach(timeout => clearTimeout(timeout));
    };
  }, [notifications, removeNotification]);
  
  return (
    <NotificationContext.Provider
      value={{
        notifications,
        addNotification,
        removeNotification,
        clearNotifications,
        enableHourlyQuotes,
        setEnableHourlyQuotes
      }}
    >
      {children}
      
      {/* Notification Display */}
      <div className="fixed top-4 right-4 z-50 max-w-sm space-y-4 w-full">
        {notifications.map((notification) => (
          <div 
            key={notification.id} 
            className={cn(
              "notification rounded-lg p-4 shadow-lg flex items-start gap-3 w-full",
              "animate-in slide-in-from-right duration-300"
            )}
          >
            {notification.image ? (
              <img 
                src={notification.image} 
                alt="Notification" 
                className="w-12 h-12 rounded-full object-cover"
              />
            ) : (
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <Bell className="w-5 h-5 text-white" />
              </div>
            )}
            
            <div className="flex-1 min-w-0">
              <h4 className="font-bold text-white">{notification.title}</h4>
              <p className="text-white/80 text-sm line-clamp-3">{notification.message}</p>
              <span className="text-xs text-white/60 mt-1 block">
                {new Date(notification.timestamp).toLocaleTimeString()}
              </span>
            </div>
            
            <button 
              onClick={() => removeNotification(notification.id)}
              className="text-white/60 hover:text-white p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </NotificationContext.Provider>
  );
};