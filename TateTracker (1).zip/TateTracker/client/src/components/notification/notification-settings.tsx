import React from 'react';
import { Bell, Volume2, Clock, Image } from 'lucide-react';
import { 
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';
import { useNotifications } from './notification-provider';
import { useToast } from '@/hooks/use-toast';

export const NotificationSettings: React.FC = () => {
  const { 
    enableHourlyQuotes, 
    setEnableHourlyQuotes,
    addNotification
  } = useNotifications();
  
  const { toast } = useToast();
  
  // Function to handle requesting notification permission
  const requestNotificationPermission = async () => {
    if (!('Notification' in window)) {
      toast({
        title: 'Notifications Not Supported',
        description: 'Your browser does not support notifications.',
        variant: 'destructive'
      });
      return;
    }
    
    if (Notification.permission === 'granted') {
      toast({
        title: 'Notifications Already Enabled',
        description: 'You have already granted notification permissions.',
      });
      return;
    }
    
    try {
      const permission = await Notification.requestPermission();
      
      if (permission === 'granted') {
        toast({
          title: 'Notifications Enabled',
          description: 'You will now receive notifications from the Top G.',
        });
        
        // Send a test notification
        addNotification({
          type: 'quote',
          title: 'Notification Test',
          message: 'Notifications are now enabled. Stay focused and disciplined.',
          image: 'https://media.newyorker.com/photos/63b5b52cd7c1b87732c9d178/master/pass/ioffe-andrew-tate.jpg'
        });
      } else {
        toast({
          title: 'Notifications Denied',
          description: 'You have denied notification permissions.',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to request notification permission.',
        variant: 'destructive'
      });
    }
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5 text-primary" />
          Notification Settings
        </CardTitle>
        <CardDescription>
          Configure how and when you receive notifications
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Notification Permission */}
        <div>
          <h3 className="text-lg font-semibold mb-2">Browser Notifications</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Allow browser notifications to receive motivational quotes and alerts even when the app is in the background.
          </p>
          
          <Button 
            onClick={requestNotificationPermission}
            className="w-full"
          >
            Enable Browser Notifications
          </Button>
        </div>
        
        <Separator />
        
        {/* Hourly Quotes */}
        <div className="flex items-center justify-between space-x-2">
          <div className="flex flex-col space-y-1">
            <div className="flex items-center space-x-2">
              <Clock className="h-4 w-4 text-primary" />
              <Label htmlFor="hourly-quotes" className="font-medium">Hourly Motivational Quotes</Label>
            </div>
            <p className="text-sm text-muted-foreground">
              Receive Andrew Tate quotes every hour to keep your mindset strong
            </p>
          </div>
          <Switch
            id="hourly-quotes"
            checked={enableHourlyQuotes}
            onCheckedChange={setEnableHourlyQuotes}
          />
        </div>
        
        {/* Future Features - These will be implemented next */}
        <Separator />
        
        {/* Alarm Sound Settings - Coming Soon */}
        <div className="flex items-center justify-between space-x-2 opacity-50">
          <div className="flex flex-col space-y-1">
            <div className="flex items-center space-x-2">
              <Volume2 className="h-4 w-4 text-primary" />
              <Label htmlFor="alarm-sounds" className="font-medium">Custom Alarm Sounds</Label>
            </div>
            <p className="text-sm text-muted-foreground">
              Set custom sounds for different notification types (Coming Soon)
            </p>
          </div>
          <Switch id="alarm-sounds" disabled />
        </div>
        
        {/* Background Settings - Coming Soon */}
        <div className="flex items-center justify-between space-x-2 opacity-50">
          <div className="flex flex-col space-y-1">
            <div className="flex items-center space-x-2">
              <Image className="h-4 w-4 text-primary" />
              <Label htmlFor="custom-bg" className="font-medium">Custom Background Image</Label>
            </div>
            <p className="text-sm text-muted-foreground">
              Set a custom background image for your app (Coming Soon)
            </p>
          </div>
          <Switch id="custom-bg" disabled />
        </div>
        
        <div className="rounded-lg bg-muted/50 p-3 mt-4">
          <p className="text-sm text-center italic text-muted-foreground">
            More advanced features are coming soon. Stay disciplined!
          </p>
        </div>
      </CardContent>
    </Card>
  );
};