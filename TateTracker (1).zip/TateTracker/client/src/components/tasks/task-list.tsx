import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Task } from "@shared/schema";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlusIcon, ArrowRightIcon } from "lucide-react";
import { Link } from "wouter";
import TaskItem from "./task-item";
import AddTaskDialog from "./add-task-dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

const TaskList = ({ limit = 5 }: { limit?: number }) => {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Fetch tasks
  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ['/api/tasks']
  });
  
  // Task complete mutation
  const completeTaskMutation = useMutation({
    mutationFn: async ({ id, completed }: { id: number, completed: boolean }) => {
      await apiRequest('PATCH', `/api/tasks/${id}/complete`, { completed });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: "Task updated",
        description: "Task status has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update task status. Please try again.",
        variant: "destructive",
      });
      console.error(error);
    }
  });
  
  // Handle task completion toggle
  const handleCompleteTask = (id: number, currentStatus: boolean) => {
    completeTaskMutation.mutate({ id, completed: !currentStatus });
  };
  
  // Limit tasks for dashboard view
  const displayedTasks = limit ? tasks.slice(0, limit) : tasks;
  
  return (
    <Card className="bg-secondary">
      <CardHeader className="flex flex-row items-center justify-between pb-2 pt-4 px-4">
        <CardTitle className="text-lg font-montserrat">Today's Tasks</CardTitle>
        <Button 
          size="sm" 
          className="bg-primary text-white"
          onClick={() => setIsAddDialogOpen(true)}
        >
          <PlusIcon className="h-4 w-4 mr-1" /> 
          Add Task
        </Button>
      </CardHeader>
      
      <CardContent className="px-4 pb-4">
        {isLoading ? (
          <div className="flex justify-center p-4">
            <span className="loading loading-spinner"></span>
          </div>
        ) : displayedTasks.length > 0 ? (
          <div className="space-y-3">
            {displayedTasks.map((task) => (
              <TaskItem 
                key={task.id} 
                task={task} 
                onComplete={handleCompleteTask} 
              />
            ))}
            
            {limit && tasks.length > limit && (
              <Link href="/tasks">
                <Button 
                  variant="ghost" 
                  className="w-full py-2 text-center text-muted-foreground text-sm hover:text-accent transition-colors"
                >
                  View all tasks <ArrowRightIcon className="h-3 w-3 ml-1" />
                </Button>
              </Link>
            )}
          </div>
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            <p>No tasks yet. Start adding tasks to crush your goals!</p>
          </div>
        )}
      </CardContent>
      
      <AddTaskDialog 
        open={isAddDialogOpen} 
        onOpenChange={setIsAddDialogOpen} 
      />
    </Card>
  );
};

export default TaskList;
