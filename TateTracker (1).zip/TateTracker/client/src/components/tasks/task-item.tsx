import { useState } from "react";
import { Task } from "@shared/schema";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { getTaskPriorityClass, getCategoryColors } from "@/lib/utils";

interface TaskItemProps {
  task: Task;
  onComplete: (id: number, completed: boolean) => void;
}

const TaskItem = ({ task, onComplete }: TaskItemProps) => {
  const [isHovered, setIsHovered] = useState(false);
  
  const categoryColors = getCategoryColors(task.category);
  const priorityClass = getTaskPriorityClass(task.priority);
  
  const handleCheckboxClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onComplete(task.id, task.completed);
  };
  
  return (
    <div 
      className={`bg-muted rounded-md p-3 task-card transition-all duration-200 ${priorityClass} cursor-pointer`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex items-center">
        <div 
          className="w-5 h-5 flex-shrink-0 mr-3"
          onClick={handleCheckboxClick}
        >
          <Checkbox 
            checked={task.completed}
            className={`${
              task.priority === 'High' 
                ? 'border-primary data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground' 
                : task.priority === 'Medium'
                ? 'border-accent data-[state=checked]:bg-accent data-[state=checked]:text-accent-foreground'
                : 'border-green-500 data-[state=checked]:bg-green-500 data-[state=checked]:text-white'
            }`}
          />
        </div>
        
        <div className={`flex-grow ${task.completed ? 'line-through opacity-70' : ''}`}>
          <p className="font-medium">{task.title}</p>
          {task.time && (
            <p className="text-xs text-muted-foreground">{task.time}</p>
          )}
        </div>
        
        <Badge className={`${categoryColors.bg} ${categoryColors.text}`}>
          {task.category}
        </Badge>
      </div>
    </div>
  );
};

export default TaskItem;
