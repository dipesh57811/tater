import { useState } from 'react';
import { Bell, X } from 'lucide-react';
import { useWebSocket, type WebSocketMessage } from '@/hooks/use-websocket';
import { Link } from 'wouter';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

export function NotificationCenter() {
  const { notifications, clearNotifications } = useWebSocket();
  const [open, setOpen] = useState(false);

  // Format timestamp
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button className="relative p-2 text-white hover:text-red-500 transition-colors">
          <Bell size={24} />
          {notifications.length > 0 && (
            <Badge 
              className="absolute -top-1 -right-1 bg-red-600 text-white border-none w-5 h-5 flex items-center justify-center p-0 text-xs"
            >
              {notifications.length}
            </Badge>
          )}
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-80 bg-black border-red-600 border-2 p-0 overflow-hidden">
        <div className="bg-red-600 text-white px-4 py-2 flex justify-between items-center">
          <h3 className="font-bold text-lg">Notifications</h3>
          <button 
            onClick={clearNotifications}
            className="text-white hover:text-red-200 transition-colors"
          >
            <X size={18} />
          </button>
        </div>
        
        <div className="max-h-96 overflow-y-auto">
          {notifications.length === 0 ? (
            <div className="py-6 px-4 text-center text-gray-400">
              No new notifications
            </div>
          ) : (
            <ul className="divide-y divide-red-600/20">
              {notifications.map((notification: WebSocketMessage, index) => (
                <li key={index} className="px-4 py-3 hover:bg-red-900/10 transition-colors">
                  {notification.type === 'new_video' && (
                    <Link 
                      to={`/videos/${notification.videoId}`}
                      className="block"
                      onClick={() => setOpen(false)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-semibold text-red-500">New Video</p>
                          <p className="text-white">{notification.title}</p>
                          <p className="text-gray-400 text-xs">{notification.category}</p>
                        </div>
                        <span className="text-gray-400 text-xs">
                          {formatTime(notification.timestamp)}
                        </span>
                      </div>
                    </Link>
                  )}
                  
                  {notification.type === 'video_liked' && (
                    <Link 
                      to={`/videos/${notification.videoId}`}
                      className="block"
                      onClick={() => setOpen(false)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-semibold text-red-500">Video Liked</p>
                          <p className="text-white">{notification.title}</p>
                          <p className="text-gray-400 text-xs">{notification.likes} total likes</p>
                        </div>
                        <span className="text-gray-400 text-xs">
                          {formatTime(notification.timestamp)}
                        </span>
                      </div>
                    </Link>
                  )}
                  
                  {notification.type === 'video_comment' && (
                    <Link 
                      to={`/videos/${notification.videoId}`}
                      className="block"
                      onClick={() => setOpen(false)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-semibold text-red-500">New Comment</p>
                          <p className="text-white">{notification.videoTitle}</p>
                          <p className="text-gray-400 text-xs italic">"{notification.comment}"</p>
                        </div>
                        <span className="text-gray-400 text-xs">
                          {formatTime(notification.timestamp)}
                        </span>
                      </div>
                    </Link>
                  )}
                  
                  {notification.type === 'coins_earned' && (
                    <Link 
                      to={`/videos/${notification.videoId}`}
                      className="block"
                      onClick={() => setOpen(false)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-semibold text-yellow-500">Coins Earned</p>
                          <p className="text-white">+{notification.coinsEarned} coins from video</p>
                          <p className="text-gray-400 text-xs">{notification.videoTitle}</p>
                        </div>
                        <span className="text-gray-400 text-xs">
                          {formatTime(notification.timestamp)}
                        </span>
                      </div>
                    </Link>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}