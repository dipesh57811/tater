import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Habit } from "@shared/schema";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlusIcon, ArrowRightIcon } from "lucide-react";
import { Link } from "wouter";
import HabitItem from "./habit-item";
import AddHabitDialog from "./add-habit-dialog";

const HabitTracker = ({ limit = 3 }: { limit?: number }) => {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  
  // Fetch habits
  const { data: habits = [], isLoading } = useQuery<Habit[]>({
    queryKey: ['/api/habits']
  });
  
  // Limit habits for dashboard view
  const displayedHabits = limit ? habits.slice(0, limit) : habits;
  
  return (
    <Card className="bg-secondary">
      <CardHeader className="flex flex-row items-center justify-between pb-2 pt-4 px-4">
        <CardTitle className="text-lg font-montserrat">Habit Tracker</CardTitle>
        <Button 
          size="sm" 
          className="bg-primary text-white"
          onClick={() => setIsAddDialogOpen(true)}
        >
          <PlusIcon className="h-4 w-4 mr-1" /> 
          Add Habit
        </Button>
      </CardHeader>
      
      <CardContent className="px-4 pb-4">
        {isLoading ? (
          <div className="flex justify-center p-4">
            <span className="loading loading-spinner"></span>
          </div>
        ) : displayedHabits.length > 0 ? (
          <div className="space-y-3">
            {displayedHabits.map((habit) => (
              <HabitItem 
                key={habit.id} 
                habit={habit} 
              />
            ))}
            
            {limit && habits.length > limit && (
              <Link href="/habits">
                <Button 
                  variant="ghost" 
                  className="w-full py-2 text-center text-muted-foreground text-sm hover:text-accent transition-colors"
                >
                  View all habits <ArrowRightIcon className="h-3 w-3 ml-1" />
                </Button>
              </Link>
            )}
          </div>
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            <p>No habits yet. Start tracking your habits to build discipline!</p>
          </div>
        )}
      </CardContent>
      
      <AddHabitDialog 
        open={isAddDialogOpen} 
        onOpenChange={setIsAddDialogOpen} 
      />
    </Card>
  );
};

export default HabitTracker;
