import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { RoutineItem, RoutineCategories } from "@shared/schema";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PencilIcon, ArrowRightIcon } from "lucide-react";
import { Link } from "wouter";
import { getCategoryColors } from "@/lib/utils";

const DailyRoutine = () => {
  // Fetch routine items
  const { data: routineItems = [], isLoading } = useQuery<RoutineItem[]>({
    queryKey: ['/api/routine']
  });
  
  return (
    <Card className="bg-secondary mt-6">
      <CardHeader className="flex flex-row items-center justify-between pb-2 pt-4 px-4">
        <CardTitle className="text-lg font-montserrat">Top G Daily Routine</CardTitle>
        <div className="flex space-x-2">
          <Button
            size="sm"
            variant="outline"

            className="border-accent text-accent"
          >
            <PencilIcon className="h-4 w-4 mr-1" />
            Edit Routine
          </Button>
          <Button
            size="sm"
            className="bg-accent text-black hover:bg-accent/90"
          >
            Apply Today
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="px-4 pb-4">
        {isLoading ? (
          <div className="flex justify-center p-4">
            <span className="loading loading-spinner"></span>
          </div>
        ) : routineItems.length > 0 ? (
          <div className="overflow-x-auto">
            <div className="min-w-max">
              <div className="grid grid-cols-12 gap-2 mb-3">
                <div className="col-span-2 text-xs text-muted-foreground">Time</div>
                <div className="col-span-3 text-xs text-muted-foreground">Activity</div>
                <div className="col-span-5 text-xs text-muted-foreground">Description</div>
                <div className="col-span-2 text-xs text-muted-foreground">Category</div>
              </div>
              
              {routineItems.map((item) => {
                const categoryColors = getCategoryColors(item.category);
                
                return (
                  <div  
     key={item.id} className="grid grid-cols-12 gap-2 bg-muted rounded-md p-2 mb-2 text-sm">
                    <div className="col-span-2">{item.time}</div>
                    <div className="col-span-3 font-medium">{item.activity}</div>
                    <div className="col-span-5 text-muted-foreground">{item.description}</div>
                    <div className="col-span-2">
                      <span className={`${categoryColors.bg} ${categoryColors.text} text-xs px-2 py-0.5 rounded-md`}>
                        {item.category}
                      </span>
                    </div>
                  </div>
                );
              })}
              
              <Link href="/routine">
                <Button 
                  variant="ghost" 
                  className="w-full py-2 mt-2 text-center text-muted-foreground text-sm hover:text-accent transition-colors"
                >
                  View full routine <ArrowRightIcon className="h-3 w-3 ml-1" />
                </Button>
              </Link>
            </div>
          </div>
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            <p>No routine set up yet. Create your Top G daily routine!</p>

          </div>
        )}
      </CardContent>
    </Card>
  );
};
export default DailyRoutine;