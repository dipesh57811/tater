import React from 'react';
import { NotificationSettings } from '@/components/notification/notification-settings';
import { Bell } from 'lucide-react';

const NotificationsPage: React.FC = () => {
  return (
    <div className="container mx-auto p-4 max-w-3xl">
      <div className="mb-6 flex items-center">
        <Bell className="mr-2 h-6 w-6 text-primary" />
        <h1 className="text-3xl font-bold">Notifications</h1>
      </div>
      
      <div className="space-y-6">
        <div className="bg-card rounded-lg p-6 border border-border">
          <p className="text-lg mb-4">
            Configure your notifications to stay motivated and on track with your goals. Receive Andrew Tate's wisdom throughout the day to maintain your discipline and focus.
          </p>
          
          <blockquote className="quote-card p-4 rounded-lg mt-4 mb-4 italic text-accent-foreground">
            "Reminder notifications are the modern-day equivalent of having a personal mentor constantly pushing you to be your best."
          </blockquote>
        </div>
        
        <NotificationSettings />
        
        <div className="bg-card rounded-lg p-6 border border-border">
          <h2 className="text-xl font-bold mb-4">Tips for Maximum Productivity</h2>
          <ul className="space-y-2 list-disc list-inside">
            <li>Enable hourly quotes to maintain your mindset throughout the day</li>
            <li>Keep browser notifications on for task reminders even when the app is closed</li>
            <li>Use the habit tracker in combination with notifications for consistent growth</li>
            <li>Remember that consistent small actions lead to massive results over time</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default NotificationsPage;