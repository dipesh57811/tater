import React, { useState, useEffect } from 'react';
import { apiRequest, queryClient } from '@/lib/queryClient';
import TateShortPlayer from '@/components/videos/tate-shorts-player';
import AdminVideoUpload from '@/components/videos/admin-video-upload';
import { Loader2 } from 'lucide-react';
import { useLocation } from 'wouter';
import { VideoCategories } from '@shared/schema';
import { useQuery } from '@tanstack/react-query';

const TateShorts: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [videos, setVideos] = useState([]);
  const [error, setError] = useState<string | null>(null);
  const [, setLocation] = useLocation();
  
  // Fetch user data to check if admin
  const { data: user } = useQuery({
    queryKey: ['/api/user'],
  });

  // Check if user is admin (id === 1)
  const isAdmin = user && user.id === 1;

  useEffect(() => {
    const fetchVideos = async () => {
      try {
        setLoading(true);
        const response = await fetch(`/api/videos?category=${VideoCategories.TATE_SHORT}`);
        
        if (!response.ok) {
          throw new Error('Failed to fetch videos');
        }
        
        const data = await response.json();
        setVideos(data);
      } catch (err) {
        console.error('Error fetching videos:', err);
        setError('Failed to load videos. Please try again later.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchVideos();
  }, []);
  
  // Add this to refresh videos after admin uploads a new one
  const handleVideoUploadSuccess = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
    // Refetch videos
    const fetchVideos = async () => {
      try {
        const response = await fetch(`/api/videos?category=${VideoCategories.TATE_SHORT}`);
        
        if (!response.ok) {
          throw new Error('Failed to fetch videos');
        }
        
        const data = await response.json();
        setVideos(data);
      } catch (err) {
        console.error('Error fetching videos:', err);
      }
    };
    
    fetchVideos();
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-950">
        <Loader2 className="w-12 h-12 text-red-500 animate-spin mb-4" />
        <p className="text-white text-xl font-bold">Loading Tate Shorts...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-950">
        <div className="text-center max-w-md p-8">
          <p className="text-red-500 text-xl font-bold mb-4">Error</p>
          <p className="text-white mb-6">{error}</p>
          <button 
            onClick={() => window.location.reload()}
            className="bg-red-800 hover:bg-red-700 text-white px-6 py-2 rounded"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  if (videos.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-950">
        <div className="text-center max-w-md p-8">
          <p className="text-white text-xl font-bold mb-4">No Shorts Available</p>
          <p className="text-gray-400 mb-6">
            There are currently no Tate Shorts available. Check back later or explore other content.
          </p>
          {isAdmin && (
            <div className="mt-4">
              <AdminVideoUpload onUploadSuccess={handleVideoUploadSuccess} />
            </div>
          )}
          <button 
            onClick={() => setLocation('/')}
            className="bg-gray-800 hover:bg-gray-700 text-white px-6 py-2 rounded mt-4"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black z-20">
      <div className="absolute top-4 left-4 z-30 flex items-center space-x-4">
        <button 
          onClick={() => setLocation('/')}
          className="bg-black/50 backdrop-blur text-white p-2 rounded-full"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <h1 className="text-white text-xl font-bold">Tate Shorts</h1>
      </div>
      
      {isAdmin && (
        <div className="absolute top-4 right-4 z-30">
          <AdminVideoUpload onUploadSuccess={handleVideoUploadSuccess} />
        </div>
      )}
      
      <TateShortPlayer videos={videos} />
    </div>
  );
};

export default TateShorts;