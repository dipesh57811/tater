import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Task, TaskCategories, TaskPriorities } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PlusIcon, SearchIcon, FilterIcon } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import AddTaskDialog from "@/components/tasks/add-task-dialog";
import TaskItem from "@/components/tasks/task-item";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

const Tasks = () => {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("All");
  const [priorityFilter, setPriorityFilter] = useState<string>("All");
  const [activeTab, setActiveTab] = useState("all");
  
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Fetch tasks
  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ['/api/tasks']
  });
  
  // Task complete mutation
  const completeTaskMutation = useMutation({
    mutationFn: async ({ id, completed }: { id: number, completed: boolean }) => {
      await apiRequest('PATCH', `/api/tasks/${id}/complete`, { completed });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: "Task updated",
        description: "Task status has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update task status. Please try again.",
        variant: "destructive",
      });
      console.error(error);
    }
  });
  
  // Handle task completion toggle
  const handleCompleteTask = (id: number, currentStatus: boolean) => {
    completeTaskMutation.mutate({ id, completed: !currentStatus });
  };
  
  // Filter tasks based on search term, category and priority
  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === "All" || task.category === categoryFilter;
    const matchesPriority = priorityFilter === "All" || task.priority === priorityFilter;
    const matchesTab = (
      activeTab === "all" || 
      (activeTab === "completed" && task.completed) || 
      (activeTab === "pending" && !task.completed)
    );
    
    return matchesSearch && matchesCategory && matchesPriority && matchesTab;
  });
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-montserrat font-bold">Tasks</h2>
          <p className="text-muted-foreground">Manage and track your daily tasks</p>
        </div>
        <Button
          className="bg-primary text-white"
          onClick={() => setIsAddDialogOpen(true)}
        >
          <PlusIcon className="h-4 w-4 mr-2" />
          Add Task
        </Button>
      </div>
      
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            className="pl-10"
            placeholder="Search tasks..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex gap-2">
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-[130px]">
              <FilterIcon className="h-4 w-4 mr-2" />
              <span>Category</span>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Categories</SelectItem>
              {Object.values(TaskCategories).map((category) => (
                <SelectItem key={category} value={category}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={priorityFilter} onValueChange={setPriorityFilter}>
            <SelectTrigger className="w-[130px]">
              <FilterIcon className="h-4 w-4 mr-2" />
              <span>Priority</span>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Priorities</SelectItem>
              {Object.values(TaskPriorities).map((priority) => (
                <SelectItem key={priority} value={priority}>
                  {priority}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="all">All Tasks</TabsTrigger>
          <TabsTrigger value="pending">Pending</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-0">
          {renderTaskList(filteredTasks, isLoading, handleCompleteTask)}
        </TabsContent>
        
        <TabsContent value="pending" className="mt-0">
          {renderTaskList(filteredTasks, isLoading, handleCompleteTask)}
        </TabsContent>
        
        <TabsContent value="completed" className="mt-0">
          {renderTaskList(filteredTasks, isLoading, handleCompleteTask)}
        </TabsContent>
      </Tabs>
      
      <AddTaskDialog
        open={isAddDialogOpen}
        onOpenChange={setIsAddDialogOpen}
      />
    </div>
  );
};

// Helper function to render task list
const renderTaskList = (
  tasks: Task[], 
  isLoading: boolean, 
  onComplete: (id: number, completed: boolean) => void
) => {
  if (isLoading) {
    return (
      <div className="flex justify-center p-8">
        <span className="loading loading-spinner"></span>
      </div>
    );
  }
  
  if (tasks.length === 0) {
    return (
      <div className="text-center py-16 text-muted-foreground">
        <p>No tasks found. Add a new task or modify your filters.</p>
      </div>
    );
  }
  
  return (
    <div className="bg-secondary rounded-lg p-4">
      <div className="space-y-3">
        {tasks.map((task) => (
          <TaskItem
            key={task.id}
            task={task}
            onComplete={onComplete}
          />
        ))}
      </div>
    </div>
  );
};

export default Tasks;
