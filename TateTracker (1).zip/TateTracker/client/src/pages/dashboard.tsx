import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { formatDate } from "@/lib/utils";
import MotivationalQuote from "@/components/motivational-quote";
import StatsGrid from "@/components/stats-grid";
import TaskList from "@/components/tasks/task-list";
import HabitTracker from "@/components/habits/habit-tracker";
import DailyRoutine from "@/components/routine/daily-routine";
import WalletDisplay from "@/components/wallet/wallet-display";
import PremiumRoutinesList from "@/components/premium/premium-routines-list";
import { AnnouncementList } from "@/components/announcements";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dumbbell, Wallet, Trophy, Bell } from "lucide-react";

const Dashboard = () => {
  const today = new Date();
  const formattedDate = formatDate(today);
  
  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bebas-neue text-red-500">THE REAL WORLD</h2>
        <p className="text-muted-foreground">{formattedDate}</p>
      </div>
      
      <div className="mb-6">
        <MotivationalQuote />
      </div>

      <div className="mb-6">
        <Card className="bg-black border-red-800">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-xl">
              <Bell className="h-5 w-5 text-red-500" />
              Announcements
            </CardTitle>
          </CardHeader>
          <CardContent>
            <AnnouncementList limit={3} />
          </CardContent>
        </Card>
      </div>
      
      <StatsGrid />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <TaskList limit={5} />
        <HabitTracker limit={3} />
      </div>
      
      <Tabs defaultValue="daily-routine" className="mb-6">
        <TabsList className="grid grid-cols-2 mb-4">
          <TabsTrigger value="daily-routine" className="data-[state=active]:bg-red-800">
            <Dumbbell className="h-4 w-4 mr-2" />
            Daily Routine
          </TabsTrigger>
          <TabsTrigger value="tate-routine" className="data-[state=active]:bg-red-800">
            <Trophy className="h-4 w-4 mr-2" />
            Tate's Routine
          </TabsTrigger>
        </TabsList>
        <TabsContent value="daily-routine">
          <DailyRoutine />
        </TabsContent>
        <TabsContent value="tate-routine">
          <Card className="bg-black border-red-800">
            <CardHeader>
              <CardTitle className="text-2xl">Andrew Tate's Daily Routine</CardTitle>
              <CardDescription>The schedule of a four-time world champion</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { time: "4:30 AM", activity: "Wake up" },
                  { time: "5:00 AM", activity: "Exercise (Run, gym, etc.)" },
                  { time: "7:00 AM", activity: "Cold shower & grooming" },
                  { time: "7:30 AM", activity: "Breakfast (High protein, low carb)" },
                  { time: "8:00 AM", activity: "Business meetings & calls" },
                  { time: "11:00 AM", activity: "Strategic planning" },
                  { time: "12:30 PM", activity: "Lunch (Clean eating)" },
                  { time: "1:30 PM", activity: "Combat sports training" },
                  { time: "3:30 PM", activity: "Business operations" },
                  { time: "6:00 PM", activity: "Second workout" },
                  { time: "7:30 PM", activity: "Dinner" },
                  { time: "8:30 PM", activity: "Reading & learning" },
                  { time: "10:00 PM", activity: "Sleep" },
                ].map((item, index) => (
                  <div key={index} className="flex border-l-4 border-red-700 pl-4 py-2 bg-gray-900/30">
                    <div className="w-24 font-bold text-red-500">{item.time}</div>
                    <div>{item.activity}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="mb-10">
        <Card className="bg-black border-red-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-2xl">
              <Trophy className="h-6 w-6 text-red-500" />
              Premium Routines
            </CardTitle>
            <CardDescription>
              Unlock exclusive Tate routines with your earned coins
            </CardDescription>
          </CardHeader>
          <CardContent>
            <PremiumRoutinesList />
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
