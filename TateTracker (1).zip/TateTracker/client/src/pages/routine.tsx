import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { RoutineItem, RoutineCategories, insertRoutineItemSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { PlusIcon, Pencil, TrashIcon, CheckIcon, XIcon } from "lucide-react";
import { 
  Dialog, 
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { getCategoryColors } from "@/lib/utils";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import TateRoutine from "@/components/routine/tate-routine";

// Create a routine item form schema
const routineItemFormSchema = insertRoutineItemSchema.extend({
  time: z.string().min(1, "Time is required"),
  activity: z.string().min(1, "Activity is required").max(100, "Activity name is too long"),
  category: z.string().min(1, "Category is required"),
  order: z.number().min(0),
});

type RoutineItemFormValues = z.infer<typeof routineItemFormSchema>;

const Routine = () => {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentRoutineItem, setCurrentRoutineItem] = useState<RoutineItem | null>(null);
  
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Fetch routine items
  const { data: routineItems = [], isLoading } = useQuery<RoutineItem[]>({
    queryKey: ['/api/routine']
  });
  
  // Sort routine items by order
  const sortedRoutineItems = [...routineItems].sort((a, b) => a.order - b.order);
  
  // Routine item create mutation
  const createRoutineItemMutation = useMutation({
    mutationFn: async (data: RoutineItemFormValues) => {
      return apiRequest('POST', '/api/routine', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/routine'] });
      toast({
        title: "Routine item created",
        description: "Your routine item has been created successfully.",
      });
      setIsAddDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create routine item. Please try again.",
        variant: "destructive",
      });
      console.error(error);
    }
  });
  
  // Routine item update mutation
  const updateRoutineItemMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: Partial<RoutineItemFormValues> }) => {
      return apiRequest('PATCH', `/api/routine/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/routine'] });
      toast({
        title: "Routine item updated",
        description: "Your routine item has been updated successfully.",
      });
      setIsEditDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update routine item. Please try again.",
        variant: "destructive",
      });
      console.error(error);
    }
  });
  
  // Routine item delete mutation
  const deleteRoutineItemMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest('DELETE', `/api/routine/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/routine'] });
      toast({
        title: "Routine item deleted",
        description: "Your routine item has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete routine item. Please try again.",
        variant: "destructive",
      });
      console.error(error);
    }
  });
  
  // Handle edit routine item
  const handleEditRoutineItem = (item: RoutineItem) => {
    setCurrentRoutineItem(item);
    setIsEditDialogOpen(true);
  };
  
  // Handle delete routine item
  const handleDeleteRoutineItem = (id: number) => {
    deleteRoutineItemMutation.mutate(id);
  };
  
  // Apply routine to today
  const handleApplyRoutine = () => {
    toast({
      title: "Routine Applied",
      description: "Your daily routine has been applied to today's schedule.",
    });
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-montserrat font-bold">Daily Routine</h2>
          <p className="text-muted-foreground">Structure your day like a Top G</p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            className="border-accent text-accent"
            onClick={() => setIsAddDialogOpen(true)}
          >
            <PlusIcon className="h-4 w-4 mr-2" />
            Add Item
          </Button>
          <Button
            className="bg-accent text-black hover:bg-accent/90"
            onClick={handleApplyRoutine}
          >
            <CheckIcon className="h-4 w-4 mr-2" />
            Apply Today
          </Button>
        </div>
      </div>
      
      <Card className="bg-gradient-to-r from-primary/20 to-accent/20 border border-accent/30 mb-6 p-6">
        <h3 className="text-xl font-bold mb-3">The Top G Schedule</h3>
        <p className="text-muted-foreground">
          "Success is not a straight line. Following a structured routine creates discipline and focus.
          Commit to your routine every day - that's what separates the successful from the failures."
        </p>
      </Card>
      
      <Tabs defaultValue="tate-routine" className="mb-6">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="tate-routine">Andrew Tate's Routine</TabsTrigger>
          <TabsTrigger value="my-routine">My Personal Routine</TabsTrigger>
        </TabsList>
        
        <TabsContent value="tate-routine">
          <TateRoutine />
        </TabsContent>
        
        <TabsContent value="my-routine">
          {isLoading ? (
            <div className="flex justify-center p-8">
              <span className="loading loading-spinner"></span>
            </div>
          ) : sortedRoutineItems.length > 0 ? (
            <div className="bg-secondary rounded-lg p-4">
              <div className="overflow-x-auto">
                <div className="min-w-max">
                  <div className="grid grid-cols-12 gap-4 mb-3 px-3">
                    <div className="col-span-2 text-sm font-medium">Time</div>
                    <div className="col-span-3 text-sm font-medium">Activity</div>
                    <div className="col-span-4 text-sm font-medium">Description</div>
                    <div className="col-span-2 text-sm font-medium">Category</div>
                    <div className="col-span-1 text-sm font-medium">Actions</div>
                  </div>
                  
                  {sortedRoutineItems.map((item) => {
                    const categoryColors = getCategoryColors(item.category);
                    
                    return (
                      <div key={item.id} className="grid grid-cols-12 gap-4 bg-muted rounded-md p-3 mb-3 items-center">
                        <div className="col-span-2 font-medium">{item.time}</div>
                        <div className="col-span-3">{item.activity}</div>
                        <div className="col-span-4 text-muted-foreground">{item.description}</div>
                        <div className="col-span-2">
                          <span className={`${categoryColors.bg} ${categoryColors.text} text-xs px-2 py-1 rounded-md`}>
                            {item.category}
                          </span>
                        </div>
                        <div className="col-span-1 flex gap-2">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0"
                            onClick={() => handleEditRoutineItem(item)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0 hover:bg-destructive/20 hover:text-destructive"
                            onClick={() => handleDeleteRoutineItem(item.id)}
                          >
                            <TrashIcon className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-secondary rounded-lg p-8 text-center">
              <p className="text-muted-foreground mb-4">
                No routine items yet. Structure your day for maximum efficiency and growth.
              </p>
              <Button
                onClick={() => setIsAddDialogOpen(true)}
                className="bg-primary hover:bg-primary/90"
              >
                <PlusIcon className="h-4 w-4 mr-2" />
                Add First Routine Item
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
      
      {/* Add Routine Item Dialog */}
      <AddRoutineItemDialog 
        open={isAddDialogOpen} 
        onOpenChange={setIsAddDialogOpen}
        onSubmit={(data) => {
          createRoutineItemMutation.mutate({
            ...data,
            userId: 1, // Default user
            order: routineItems.length // Add to the end
          });
        }}
      />
      
      {/* Edit Routine Item Dialog */}
      {currentRoutineItem && (
        <EditRoutineItemDialog 
          open={isEditDialogOpen} 
          onOpenChange={setIsEditDialogOpen}
          routineItem={currentRoutineItem}
          onSubmit={(data) => {
            updateRoutineItemMutation.mutate({
              id: currentRoutineItem.id,
              data
            });
          }}
        />
      )}
    </div>
  );
};

// Add Routine Item Dialog
interface AddRoutineItemDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: RoutineItemFormValues) => void;
}

const AddRoutineItemDialog = ({ open, onOpenChange, onSubmit }: AddRoutineItemDialogProps) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Initialize form with default values
  const form = useForm<RoutineItemFormValues>({
    resolver: zodResolver(routineItemFormSchema),
    defaultValues: {
      userId: 1, // Default user
      time: "",
      activity: "",
      description: "",
      category: Object.values(RoutineCategories)[0],
      order: 0
    }
  });
  
  const handleSubmit = (data: RoutineItemFormValues) => {
    setIsSubmitting(true);
    onSubmit(data);
    form.reset();
    setIsSubmitting(false);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-secondary text-white sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">Add Routine Item</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="time"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Time</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. 5:00 AM" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {Object.values(RoutineCategories).map((category) => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="activity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Activity</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter activity name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Enter activity description" 
                      className="resize-none" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter className="gap-2">
              <DialogClose asChild>
                <Button type="button" variant="outline">Cancel</Button>
              </DialogClose>
              <Button 
                type="submit" 
                className="bg-primary hover:bg-primary/90"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Adding...' : 'Add to Routine'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};

// Edit Routine Item Dialog
interface EditRoutineItemDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  routineItem: RoutineItem;
  onSubmit: (data: Partial<RoutineItemFormValues>) => void;
}

const EditRoutineItemDialog = ({ 
  open, 
  onOpenChange, 
  routineItem, 
  onSubmit 
}: EditRoutineItemDialogProps) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Initialize form with current values
  const form = useForm<RoutineItemFormValues>({
    resolver: zodResolver(routineItemFormSchema),
    defaultValues: {
      userId: routineItem.userId,
      time: routineItem.time,
      activity: routineItem.activity,
      description: routineItem.description || "",
      category: routineItem.category,
      order: routineItem.order
    }
  });
  
  const handleSubmit = (data: RoutineItemFormValues) => {
    setIsSubmitting(true);
    onSubmit(data);
    setIsSubmitting(false);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-secondary text-white sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">Edit Routine Item</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="time"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Time</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {Object.values(RoutineCategories).map((category) => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="activity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Activity</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      className="resize-none" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter className="gap-2">
              <DialogClose asChild>
                <Button type="button" variant="outline">Cancel</Button>
              </DialogClose>
              <Button 
                type="submit" 
                className="bg-primary hover:bg-primary/90"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Saving...' : 'Save Changes'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};

export default Routine;
