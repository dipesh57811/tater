import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Flame, Lock, User, Trophy, ChevronRight } from "lucide-react";

const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

const registerSchema = loginSchema.extend({
  confirmPassword: z.string().min(6, "Password must be at least 6 characters"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

const AuthPage = () => {
  const [activeTab, setActiveTab] = useState<string>("login");
  const [_, navigate] = useLocation();
  const { user, login, register, isLoading } = useAuth();
  const { toast } = useToast();

  // Redirect to dashboard if user is already logged in
  useEffect(() => {
    if (user) {
      navigate("/");
    }
  }, [user, navigate]);

  const loginForm = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const registerForm = useForm<z.infer<typeof registerSchema>>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
    },
  });

  const onLoginSubmit = async (values: z.infer<typeof loginSchema>) => {
    try {
      await login(values.username, values.password);
    } catch (error) {
      toast({
        title: "Login failed",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    }
  };

  const onRegisterSubmit = async (values: z.infer<typeof registerSchema>) => {
    try {
      const { confirmPassword, ...registerData } = values;
      await register(registerData.username, registerData.password);
    } catch (error) {
      toast({
        title: "Registration failed",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="flex min-h-screen bg-black text-white">
      {/* Form Section */}
      <div className="w-full md:w-1/2 flex items-center justify-center p-4 md:p-8">
        <Card className="w-full max-w-md bg-zinc-900 border-red-600 border-2">
          <CardHeader className="space-y-1">
            <CardTitle className="text-3xl font-bold tracking-tight text-center text-red-600">
              TOPG MINDSET
            </CardTitle>
            <CardDescription className="text-center text-gray-300">
              Enter the matrix and unlock your potential
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="login" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2 bg-zinc-800">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="register">Register</TabsTrigger>
              </TabsList>

              <TabsContent value="login" className="mt-4">
                <Form {...loginForm}>
                  <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                    <FormField
                      control={loginForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-red-500">
                                <User className="h-4 w-4" />
                              </span>
                              <Input
                                {...field}
                                disabled={isLoading}
                                placeholder="Enter username"
                                className="bg-zinc-800 pl-10"
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={loginForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-red-500">
                                <Lock className="h-4 w-4" />
                              </span>
                              <Input
                                {...field}
                                type="password"
                                disabled={isLoading}
                                placeholder="Enter password"
                                className="bg-zinc-800 pl-10"
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button
                      type="submit"
                      disabled={isLoading}
                      className="w-full bg-red-600 hover:bg-red-700"
                    >
                      {isLoading ? "Logging in..." : "Log in"}
                    </Button>
                  </form>
                </Form>
                <div className="mt-4 text-center text-sm text-gray-400">
                  <span>Don't have an account? </span>
                  <button
                    onClick={() => setActiveTab("register")}
                    className="text-red-500 hover:text-red-400 font-semibold"
                  >
                    Register
                  </button>
                </div>
              </TabsContent>

              <TabsContent value="register" className="mt-4">
                <Form {...registerForm}>
                  <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                    <FormField
                      control={registerForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-red-500">
                                <User className="h-4 w-4" />
                              </span>
                              <Input
                                {...field}
                                disabled={isLoading}
                                placeholder="Choose a username"
                                className="bg-zinc-800 pl-10"
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={registerForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-red-500">
                                <Lock className="h-4 w-4" />
                              </span>
                              <Input
                                {...field}
                                type="password"
                                disabled={isLoading}
                                placeholder="Choose a password"
                                className="bg-zinc-800 pl-10"
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={registerForm.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Confirm Password</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-red-500">
                                <Lock className="h-4 w-4" />
                              </span>
                              <Input
                                {...field}
                                type="password"
                                disabled={isLoading}
                                placeholder="Confirm your password"
                                className="bg-zinc-800 pl-10"
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button
                      type="submit"
                      disabled={isLoading}
                      className="w-full bg-red-600 hover:bg-red-700"
                    >
                      {isLoading ? "Creating account..." : "Create account"}
                    </Button>
                  </form>
                </Form>
                <div className="mt-4 text-center text-sm text-gray-400">
                  <span>Already have an account? </span>
                  <button
                    onClick={() => setActiveTab("login")}
                    className="text-red-500 hover:text-red-400 font-semibold"
                  >
                    Log in
                  </button>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="justify-center border-t border-gray-800 pt-4">
            <p className="text-xs text-gray-400">
              By continuing, you agree to become a Top G and escape the Matrix
            </p>
          </CardFooter>
        </Card>
      </div>

      {/* Hero Section */}
      <div className="hidden md:flex md:w-1/2 bg-gradient-to-br from-black to-red-900 flex-col justify-center p-8">
        <div className="space-y-6 max-w-lg mx-auto">
          <h1 className="text-5xl font-bold tracking-tight text-white">
            Become the <span className="text-red-500">Top G</span> you were meant to be
          </h1>
          <p className="text-xl text-gray-300">
            Escape the Matrix. Build discipline. Conquer your goals and develop the mindset of a champion.
          </p>
          
          <div className="space-y-4 mt-8">
            <div className="flex items-start space-x-3">
              <div className="bg-red-600 p-2 rounded">
                <Flame className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-bold">Daily Habits Tracking</h3>
                <p className="text-gray-400">Build discipline with consistent daily habits</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-3">
              <div className="bg-red-600 p-2 rounded">
                <Trophy className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-bold">Level Up System</h3>
                <p className="text-gray-400">Progress from Initiate G to Top G with achievable milestones</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-3">
              <div className="bg-red-600 p-2 rounded">
                <ChevronRight className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-bold">Exclusive Content</h3>
                <p className="text-gray-400">Access motivational videos and premium routines</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;