import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Video } from '@shared/schema';
import { NotificationCenter } from '@/components/notifications/notification-center';
import { VideosGrid } from '@/components/videos/videos-grid';
import { VideoUploadDialog } from '@/components/videos/video-upload-dialog';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { Helmet } from 'react-helmet';

export default function VideosPage() {
  const [openUploadDialog, setOpenUploadDialog] = useState(false);
  
  // Fetch all videos
  const { data: videos = [], isLoading } = useQuery({
    queryKey: ['/api/videos'],
    queryFn: async () => {
      const response = await apiRequest('/api/videos');
      return response as Video[];
    }
  });

  return (
    <>
      <Helmet>
        <title>Tate Videos | TateTasks</title>
      </Helmet>
      
      <div className="container mx-auto px-4 py-6">
        <div className="mb-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-white">Tate Short Videos</h1>
            <p className="text-gray-400 mt-1">
              Watch and learn from the Top G himself. Earn coins by watching videos.
            </p>
          </div>
          
          <div className="flex items-center gap-4">
            <NotificationCenter />
            <Button 
              className="bg-red-600 hover:bg-red-700 text-white" 
              onClick={() => setOpenUploadDialog(true)}
            >
              <Plus className="mr-2 h-4 w-4" />
              Upload Video
            </Button>
          </div>
        </div>

        {isLoading ? (
          <div className="py-20 flex justify-center">
            <div className="animate-pulse flex flex-col items-center">
              <div className="h-8 w-64 bg-gray-800 rounded mb-4"></div>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 w-full">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="bg-gray-800 rounded-md h-64 w-full"></div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <VideosGrid videos={videos} />
        )}
      </div>
      
      <VideoUploadDialog open={openUploadDialog} onOpenChange={setOpenUploadDialog} />
    </>
  );
}