import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Habit } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PlusIcon, SearchIcon, SwordIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AddHabitDialog from "@/components/habits/add-habit-dialog";
import HabitItem from "@/components/habits/habit-item";
import { getStreakText } from "@/lib/utils";

const Habits = () => {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("all");
  
  // Fetch habits
  const { data: habits = [], isLoading } = useQuery<Habit[]>({
    queryKey: ['/api/habits']
  });
  
  // Filter habits based on search term and active streak
  const filteredHabits = habits.filter(habit => {
    const matchesSearch = habit.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTab = 
      activeTab === "all" || 
      (activeTab === "active" && habit.streak > 0) || 
      (activeTab === "inactive" && habit.streak === 0);
    
    return matchesSearch && matchesTab;
  });
  
  // Sort by streak (highest first)
  const sortedHabits = [...filteredHabits].sort((a, b) => b.streak - a.streak);
  
  // Calculate total streak (sum of all habit streaks)
  const totalStreak = habits.reduce((sum, habit) => sum + habit.streak, 0);
  const streakText = getStreakText(totalStreak);
  
  // Motivational quotes based on total streak
  const getMotivationalQuote = () => {
    if (totalStreak === 0) return "Your legacy starts now. Begin building your discipline empire.";
    if (totalStreak < 10) return "The Matrix wants you to fail. KEEP GOING. Prove them wrong.";
    if (totalStreak < 30) return "While others sleep, you build discipline. This is how legends are made.";
    if (totalStreak < 50) return "Your discipline is becoming unstoppable. You are escaping the Matrix.";
    return "You embody what it means to be a Top G. Your discipline is your weapon.";
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-3xl font-['Bebas_Neue'] tracking-wider text-accent">YOUR DAILY CHALLENGES</h2>
          <p className="text-muted-foreground">Track your progress and build your empire</p>
        </div>
        <Button
          className="bg-accent text-black hover:bg-accent/90 font-bold"
          onClick={() => setIsAddDialogOpen(true)}
        >
          <PlusIcon className="h-4 w-4 mr-2" />
          FORGE NEW HABIT
        </Button>
      </div>
      
      <Card className="bg-gradient-to-r from-black to-primary/40 border border-accent mb-6 overflow-hidden relative">
        <div className="absolute inset-0 opacity-10 bg-[url('https://images.unsplash.com/photo-1517963879433-6ad2b056d712?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80')] bg-cover bg-center"></div>
        <CardContent className="p-6 relative z-10">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h3 className="text-2xl font-['Bebas_Neue'] tracking-wide text-white mb-1">TOTAL STREAK POWER</h3>
              <p className="text-accent mb-2 font-medium">{streakText}</p>
              <p className="text-sm text-muted-foreground max-w-md">{getMotivationalQuote()}</p>
            </div>
            <div className="bg-black/30 p-4 rounded-lg border border-accent/30">
              <div className="text-6xl font-['Bebas_Neue'] tracking-wide text-accent text-center">
                {totalStreak}
                <span className="text-xl text-muted-foreground font-normal block"> CONSECUTIVE DAYS</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-accent h-4 w-4" />
          <Input
            className="pl-10 border-accent/30 focus:border-accent focus-visible:ring-accent/30"
            placeholder="Search habits..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      
      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-4 w-full bg-gradient-to-r from-black to-muted">
          <TabsTrigger 
            value="all"
            className="data-[state=active]:bg-accent data-[state=active]:text-black data-[state=active]:font-bold"
          >
            ALL HABITS
          </TabsTrigger>
          <TabsTrigger 
            value="active"
            className="data-[state=active]:bg-accent data-[state=active]:text-black data-[state=active]:font-bold"
          >
            ELITE STREAKS
          </TabsTrigger>
          <TabsTrigger 
            value="inactive"
            className="data-[state=active]:bg-accent data-[state=active]:text-black data-[state=active]:font-bold"
          >
            NEEDS WORK
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-0">
          {renderHabitList(sortedHabits, isLoading, () => setIsAddDialogOpen(true))}
        </TabsContent>
        
        <TabsContent value="active" className="mt-0">
          {renderHabitList(sortedHabits, isLoading, () => setIsAddDialogOpen(true))}
        </TabsContent>
        
        <TabsContent value="inactive" className="mt-0">
          {renderHabitList(sortedHabits, isLoading, () => setIsAddDialogOpen(true))}
        </TabsContent>
      </Tabs>
      
      <AddHabitDialog
        open={isAddDialogOpen}
        onOpenChange={setIsAddDialogOpen}
      />
    </div>
  );
};

// Helper function to render habit list
const renderHabitList = (habits: Habit[], isLoading: boolean, openAddDialog: () => void) => {
  if (isLoading) {
    return (
      <div className="flex justify-center p-8">
        <span className="loading loading-spinner"></span>
      </div>
    );
  }
  
  if (habits.length === 0) {
    return (
      <div className="text-center py-16 border border-accent/20 rounded-lg bg-gradient-to-b from-muted/50 to-black/50">
        <div className="mb-4">
          <SwordIcon className="h-12 w-12 text-accent mx-auto opacity-70" />
        </div>
        <h3 className="text-2xl font-['Bebas_Neue'] tracking-wider text-accent mb-2">NO DISCIPLINE YET</h3>
        <p className="text-muted-foreground max-w-md mx-auto">
          The Matrix wants you weak and undisciplined. Beat the system by creating your first habit.
        </p>
        <Button 
          className="mt-4 bg-accent text-black hover:bg-accent/90 font-bold"
          onClick={openAddDialog}
        >
          <PlusIcon className="h-4 w-4 mr-2" />
          START YOUR JOURNEY
        </Button>
      </div>
    );
  }
  
  return (
    <div className="bg-secondary rounded-lg p-4">
      <div className="space-y-4">
        {habits.map((habit) => (
          <HabitItem
            key={habit.id}
            habit={habit}
          />
        ))}
      </div>
    </div>
  );
};

export default Habits;
