import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useParams } from 'wouter';
import { Video } from '@shared/schema';
import { VideoPlayer } from '@/components/videos/video-player';
import { VideoCard } from '@/components/videos/video-card';
import { Skeleton } from '@/components/ui/skeleton';
import { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

export default function VideoDetailPage() {
  const { id } = useParams<{ id: string }>();
  const videoId = parseInt(id);
  
  // Fetch video details
  const { data: video, isLoading: isVideoLoading } = useQuery({
    queryKey: ['/api/videos', videoId],
    queryFn: async () => {
      const response = await apiRequest(`/api/videos/${videoId}`);
      return response as Video;
    },
    enabled: !isNaN(videoId)
  });
  
  // Fetch related videos (different videos in the same category)
  const { data: relatedVideos = [], isLoading: isRelatedLoading } = useQuery({
    queryKey: ['/api/videos', 'related', video?.category],
    queryFn: async () => {
      const response = await apiRequest(`/api/videos?category=${video?.category}`);
      return (response as Video[]).filter(v => v.id !== videoId);
    },
    enabled: !!video
  });
  
  // Scroll to top when navigating to a new video
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [videoId]);

  if (!video && !isVideoLoading) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-3xl font-bold text-white mb-4">Video Not Found</h1>
        <p className="text-gray-400 mb-8">The video you're looking for doesn't exist or has been removed.</p>
        <Link to="/videos">
          <Button variant="outline" className="bg-red-900 hover:bg-red-800 text-white border-red-700">
            Back to Videos
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>{video ? `${video.title} | TateTasks` : 'Loading Video...'}</title>
      </Helmet>
      
      <div className="container mx-auto px-4 py-6">
        <div className="mb-6">
          <Link to="/videos">
            <Button variant="ghost" className="text-white hover:text-red-500 -ml-4 mb-2">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Videos
            </Button>
          </Link>
        </div>
        
        {isVideoLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-[60vh] w-full bg-gray-800" />
            <Skeleton className="h-12 w-3/4 bg-gray-800" />
            <Skeleton className="h-6 w-1/2 bg-gray-800" />
          </div>
        ) : video ? (
          <VideoPlayer video={video} />
        ) : null}
        
        <div className="mt-12">
          <h2 className="text-xl font-bold text-white mb-6">Related Videos</h2>
          
          {isRelatedLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {[...Array(4)].map((_, i) => (
                <Skeleton key={i} className="h-48 w-full bg-gray-800" />
              ))}
            </div>
          ) : relatedVideos.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {relatedVideos.slice(0, 4).map((video) => (
                <div key={video.id}>
                  {/* Use compact variant for related videos */}
                  <div className="transition-transform hover:scale-105">
                    <Link to={`/videos/${video.id}`}>
                      <VideoCard video={video} variant="compact" />
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-400 text-center py-8">No related videos found</p>
          )}
        </div>
      </div>
    </>
  );
}