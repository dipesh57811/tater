import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";

// Check if all required Firebase environment variables are available
const hasValidFirebaseConfig = 
  import.meta.env.VITE_FIREBASE_API_KEY &&
  import.meta.env.VITE_FIREBASE_AUTH_DOMAIN &&
  import.meta.env.VITE_FIREBASE_PROJECT_ID &&
  import.meta.env.VITE_FIREBASE_STORAGE_BUCKET &&
  import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID &&
  import.meta.env.VITE_FIREBASE_APP_ID;

// Create mock objects if Firebase keys are not available
const mockAuth = {
  currentUser: null,
  onAuthStateChanged: (callback) => {
    callback(null);
    return () => {}; // Return unsubscribe function
  },
  signInWithEmailAndPassword: () => Promise.resolve(null),
  createUserWithEmailAndPassword: () => Promise.resolve(null),
  signOut: () => Promise.resolve()
};

const mockFirestore = {
  collection: () => ({
    doc: () => ({
      get: () => Promise.resolve({ exists: false, data: () => ({}) }),
      set: () => Promise.resolve()
    }),
    add: () => Promise.resolve({ id: 'mock-id' }),
    where: () => ({
      get: () => Promise.resolve({ docs: [] })
    })
  })
};

const mockStorage = {
  ref: () => ({
    put: () => Promise.resolve(),
    getDownloadURL: () => Promise.resolve('https://example.com/placeholder.jpg')
  })
};

let app, db, auth, storage;

if (hasValidFirebaseConfig) {
  const firebaseConfig = {
    apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
    authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
    projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
    storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
    messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
    appId: import.meta.env.VITE_FIREBASE_APP_ID
  };
  
  // Initialize Firebase only if we have valid config
  try {
    app = initializeApp(firebaseConfig);
    db = getFirestore(app);
    auth = getAuth(app);
    storage = getStorage(app);
    console.log('Firebase initialized successfully');
  } catch (error) {
    console.error('Firebase initialization error:', error);
    app = null;
    db = mockFirestore;
    auth = mockAuth;
    storage = mockStorage;
  }
} else {
  console.warn('Firebase config not found, using mock implementations');
  app = null;
  db = mockFirestore;
  auth = mockAuth;
  storage = mockStorage;
}

export { db, auth, storage };
export default app;