import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"
import { format } from "date-fns";
import { Task, TaskPriority } from "@shared/schema";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(date: Date | string): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return format(dateObj, 'EEEE, MMMM d, yyyy');
}

export function getTaskPriorityClass(priority: TaskPriority | string): string {
  switch (priority?.toLowerCase()) {
    case 'high':
      return 'priority-high';
    case 'medium':
      return 'priority-medium';
    case 'low':
      return 'priority-low';
    default:
      return '';
  }
}

export function getCategoryColors(category: string): { bg: string, text: string } {
  switch (category?.toLowerCase()) {
    case 'work':
      return { bg: 'bg-green-500/20', text: 'text-green-500' };
    case 'fitness':
      return { bg: 'bg-accent/20', text: 'text-accent' };
    case 'mindset':
      return { bg: 'bg-primary/20', text: 'text-primary' };
    case 'business':
      return { bg: 'bg-blue-500/20', text: 'text-blue-500' };
    case 'discipline':
      return { bg: 'bg-primary/20', text: 'text-primary' };
    case 'health':
      return { bg: 'bg-accent/20', text: 'text-accent' };
    default:
      return { bg: 'bg-muted', text: 'text-muted-foreground' };
  }
}

export function getWeekDayLetter(dayIndex: number): string {
  const days = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  return days[dayIndex];
}

export function calculateCompletedTasks(tasks: Task[]): { completed: number, total: number } {
  const total = tasks.length;
  const completed = tasks.filter(task => task.completed).length;
  return { completed, total };
}

export function getStreakText(streak: number): string {
  if (streak === 0) return "Start your streak today!";
  if (streak === 1) return "1 day streak - Keep going!";
  if (streak < 7) return `${streak} day streak - Building momentum!`;
  if (streak < 30) return `${streak} day streak - Impressive discipline!`;
  return `${streak} day streak - True Top G status!`;
}
