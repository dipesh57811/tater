import { pgTable, text, serial, integer, boolean, timestamp, uniqueIndex, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Create video category enum
export const videoCategories = pgEnum("video_category", [
  "tate_short",
  "tate_long", 
  "tate_podcast",
  "tate_vlog",
  "tate_edit"
]);

// Create level name enum
export const levelNameEnum = pgEnum("level_name", [
  "initiate_g",
  "disciplined_g",
  "relentless_g",
  "unbreakable_g",
  "elite_g",
  "top_g"
]);

// Create challenge category enum
export const challengeCategoryEnum = pgEnum("challenge_category", [
  "daily",
  "weekly",
  "special",
  "community"
]);

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  level: integer("level").default(1).notNull(),
  levelProgress: integer("level_progress").default(0).notNull(),
  xp: integer("xp").default(0).notNull(),
  xpTotal: integer("xp_total").default(0).notNull(),
  levelName: levelNameEnum("level_name").default("initiate_g").notNull(),
  currentStreak: integer("current_streak").default(0).notNull(),
  coins: integer("coins").default(0).notNull(),
  unlocks: text("unlocks").array().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  lastLevelUp: timestamp("last_level_up").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Task schema
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  priority: text("priority").notNull(),
  completed: boolean("completed").default(false).notNull(),
  dueDate: timestamp("due_date"),
  time: text("time"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  createdAt: true,
});

// Habit schema
export const habits = pgTable("habits", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  streak: integer("streak").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertHabitSchema = createInsertSchema(habits).omit({
  id: true,
  streak: true,
  createdAt: true,
});

// Habit Completion schema
export const habitCompletions = pgTable("habit_completions", {
  id: serial("id").primaryKey(),
  habitId: integer("habit_id").references(() => habits.id).notNull(),
  completedDate: timestamp("completed_date").defaultNow().notNull(),
});

export const insertHabitCompletionSchema = createInsertSchema(habitCompletions).omit({
  id: true,
});

// Daily Routine schema
export const routineItems = pgTable("routine_items", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  time: text("time").notNull(),
  activity: text("activity").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  order: integer("order").notNull(),
});

export const insertRoutineItemSchema = createInsertSchema(routineItems).omit({
  id: true,
});

// Quotes schema
export const quotes = pgTable("quotes", {
  id: serial("id").primaryKey(),
  text: text("text").notNull(),
  author: text("author").default("Andrew Tate").notNull(),
});

export const insertQuoteSchema = createInsertSchema(quotes).omit({
  id: true,
});

// Premium routines schema
export const premiumRoutines = pgTable("premium_routines", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  cost: integer("cost").notNull(),
  details: text("details").notNull(),
  isLocked: boolean("is_locked").default(true).notNull(),
});

export const insertPremiumRoutineSchema = createInsertSchema(premiumRoutines).omit({
  id: true,
});

// User premium routines (to track which users have unlocked which routines)
export const userPremiumRoutines = pgTable("user_premium_routines", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  routineId: integer("routine_id").references(() => premiumRoutines.id).notNull(),
  unlockedAt: timestamp("unlocked_at").defaultNow().notNull(),
});

export const insertUserPremiumRoutineSchema = createInsertSchema(userPremiumRoutines).omit({
  id: true,
  unlockedAt: true,
});

// Videos schema
export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  title: text("title").notNull(),
  description: text("description"),
  url: text("url").notNull(),
  thumbnailUrl: text("thumbnail_url"),
  category: videoCategories("category").notNull(),
  views: integer("views").default(0).notNull(),
  likes: integer("likes").default(0).notNull(),
  isPublished: boolean("is_published").default(true).notNull(),
  isOfficial: boolean("is_official").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertVideoSchema = createInsertSchema(videos).omit({
  id: true,
  views: true,
  likes: true,
  createdAt: true,
});

// Video comments schema
export const videoComments = pgTable("video_comments", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").references(() => videos.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertVideoCommentSchema = createInsertSchema(videoComments).omit({
  id: true,
  createdAt: true,
});

// Announcements schema
export const announcements = pgTable("announcements", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  isPinned: boolean("is_pinned").default(false).notNull(),
  type: text("type").default("general").notNull(), // general, update, alert, hiring
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertAnnouncementSchema = createInsertSchema(announcements).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Community challenges schema
export const challenges = pgTable("challenges", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: challengeCategoryEnum("category").default("community").notNull(),
  xpReward: integer("xp_reward").notNull(),
  coinReward: integer("coin_reward").default(0).notNull(),
  requiredLevel: integer("required_level").default(1).notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  target: integer("target").notNull(), // Number of tasks/habits to complete
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  createdBy: integer("created_by").references(() => users.id),
  completedCount: integer("completed_count").default(0),
  imageUrl: text("image_url"),
});

export const insertChallengeSchema = createInsertSchema(challenges).omit({
  id: true,
  createdAt: true,
  completedCount: true,
});

// User challenge participation schema
export const userChallenges = pgTable("user_challenges", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  challengeId: integer("challenge_id").references(() => challenges.id).notNull(),
  progress: integer("progress").default(0).notNull(),
  isCompleted: boolean("is_completed").default(false).notNull(),
  completedAt: timestamp("completed_at"),
  joinedAt: timestamp("joined_at").defaultNow().notNull(),
});

export const insertUserChallengeSchema = createInsertSchema(userChallenges).omit({
  id: true,
  progress: true,
  isCompleted: true,
  completedAt: true,
  joinedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;

export type Habit = typeof habits.$inferSelect;
export type InsertHabit = z.infer<typeof insertHabitSchema>;

export type HabitCompletion = typeof habitCompletions.$inferSelect;
export type InsertHabitCompletion = z.infer<typeof insertHabitCompletionSchema>;

export type RoutineItem = typeof routineItems.$inferSelect;
export type InsertRoutineItem = z.infer<typeof insertRoutineItemSchema>;

export type Quote = typeof quotes.$inferSelect;
export type InsertQuote = z.infer<typeof insertQuoteSchema>;

export type PremiumRoutine = typeof premiumRoutines.$inferSelect;
export type InsertPremiumRoutine = z.infer<typeof insertPremiumRoutineSchema>;

export type UserPremiumRoutine = typeof userPremiumRoutines.$inferSelect;
export type InsertUserPremiumRoutine = z.infer<typeof insertUserPremiumRoutineSchema>;

export type Video = typeof videos.$inferSelect;
export type InsertVideo = z.infer<typeof insertVideoSchema>;

export type VideoComment = typeof videoComments.$inferSelect;
export type InsertVideoComment = z.infer<typeof insertVideoCommentSchema>;

export type Announcement = typeof announcements.$inferSelect;
export type InsertAnnouncement = z.infer<typeof insertAnnouncementSchema>;

export type Challenge = typeof challenges.$inferSelect;
export type InsertChallenge = z.infer<typeof insertChallengeSchema>;

export type UserChallenge = typeof userChallenges.$inferSelect;
export type InsertUserChallenge = z.infer<typeof insertUserChallengeSchema>;

// Enums for frontend use
export const TaskCategories = {
  WORK: "Work",
  FITNESS: "Fitness",
  MINDSET: "Mindset",
  BUSINESS: "Business",
  PERSONAL: "Personal",
} as const;

export const TaskPriorities = {
  HIGH: "High",
  MEDIUM: "Medium",
  LOW: "Low",
} as const;

export const RoutineCategories = {
  DISCIPLINE: "Discipline",
  HEALTH: "Health",
  FITNESS: "Fitness",
  MINDSET: "Mindset",
  WORK: "Work",
  BUSINESS: "Business",
} as const;

export const VideoCategories = {
  TATE_SHORT: "tate_short",
  TATE_LONG: "tate_long",
  TATE_PODCAST: "tate_podcast",
  TATE_VLOG: "tate_vlog",
  TATE_EDIT: "tate_edit",
} as const;

export const AnnouncementTypes = {
  GENERAL: "general",
  UPDATE: "update",
  ALERT: "alert",
  HIRING: "hiring",
} as const;

export const ChallengeCategories = {
  DAILY: "daily",
  WEEKLY: "weekly",
  SPECIAL: "special",
  COMMUNITY: "community",
} as const;

export const LevelNames = {
  INITIATE_G: "initiate_g",
  DISCIPLINED_G: "disciplined_g",
  RELENTLESS_G: "relentless_g",
  UNBREAKABLE_G: "unbreakable_g",
  ELITE_G: "elite_g",
  TOP_G: "top_g"
} as const;

export const LevelInfo = {
  1: {
    name: "Initiate G",
    xpNeeded: 0,
    icon: "🔰",
    rewards: "Access to Basic Habits"
  },
  2: {
    name: "Disciplined G",
    xpNeeded: 500,
    icon: "💪",
    rewards: "Unlock TRW Motivational Quotes"
  },
  3: {
    name: "Relentless G",
    xpNeeded: 2000,
    icon: "🥊",
    rewards: "Unlock Custom Sound Effects"
  },
  4: {
    name: "Unbreakable G",
    xpNeeded: 5000,
    icon: "🦅",
    rewards: "Unlock Premium Routines & Features"
  },
  5: {
    name: "Elite G",
    xpNeeded: 10000,
    icon: "🏆",
    rewards: "Unlock Exclusive TRW Coins + Special Badge"
  },
  6: {
    name: "Top G",
    xpNeeded: 25000,
    icon: "👑",
    rewards: "Unlock Everything + \"Top G\" Theme"
  }
} as const;

export type TaskCategory = keyof typeof TaskCategories;
export type TaskPriority = keyof typeof TaskPriorities;
export type RoutineCategory = keyof typeof RoutineCategories;
export type VideoCategory = keyof typeof VideoCategories;
export type AnnouncementType = keyof typeof AnnouncementTypes;
export type ChallengeCategory = keyof typeof ChallengeCategories;
export type LevelName = keyof typeof LevelNames;
