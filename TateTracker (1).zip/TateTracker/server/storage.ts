import { 
  users, type User, type InsertUser,
  tasks, type Task, type InsertTask,
  habits, type Habit, type InsertHabit,
  habitCompletions, type HabitCompletion, type InsertHabitCompletion,
  routineItems, type RoutineItem, type InsertRoutineItem,
  quotes, type Quote, type InsertQuote,
  premiumRoutines, type PremiumRoutine, type InsertPremiumRoutine,
  userPremiumRoutines, type UserPremiumRoutine, type InsertUserPremiumRoutine,
  videos, type Video, type InsertVideo,
  videoComments, type VideoComment, type InsertVideoComment,
  announcements, type Announcement, type InsertAnnouncement,
  challenges, type Challenge, type InsertChallenge,
  userChallenges, type UserChallenge, type InsertUserChallenge
} from "@shared/schema";
import { 
  TaskPriorities, 
  TaskCategories, 
  RoutineCategories, 
  VideoCategories, 
  AnnouncementTypes, 
  ChallengeCategories,
  LevelNames,
  LevelInfo
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, between, sql, inArray } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStreak(userId: number, streak: number): Promise<User>;
  updateUserLevel(userId: number, level: number, progress: number): Promise<User>;
  updateUserCoins(userId: number, coins: number): Promise<User>;

  // Task methods
  getTasks(userId: number): Promise<Task[]>;
  getTaskById(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<InsertTask>): Promise<Task | undefined>;
  completeTask(id: number, completed: boolean): Promise<Task | undefined>;
  deleteTask(id: number): Promise<boolean>;

  // Habit methods
  getHabits(userId: number): Promise<Habit[]>;
  getHabitById(id: number): Promise<Habit | undefined>;
  createHabit(habit: InsertHabit): Promise<Habit>;
  updateHabit(id: number, habit: Partial<InsertHabit>): Promise<Habit | undefined>;
  updateHabitStreak(id: number, streak: number): Promise<Habit | undefined>;
  deleteHabit(id: number): Promise<boolean>;

  // Habit completion methods
  getHabitCompletions(habitId: number): Promise<HabitCompletion[]>;
  createHabitCompletion(completion: InsertHabitCompletion): Promise<HabitCompletion>;
  getHabitCompletionsForDate(habitId: number, date: Date): Promise<HabitCompletion[]>;
  
  // Routine methods
  getRoutineItems(userId: number): Promise<RoutineItem[]>;
  getRoutineItemById(id: number): Promise<RoutineItem | undefined>;
  createRoutineItem(item: InsertRoutineItem): Promise<RoutineItem>;
  updateRoutineItem(id: number, item: Partial<InsertRoutineItem>): Promise<RoutineItem | undefined>;
  deleteRoutineItem(id: number): Promise<boolean>;

  // Quote methods
  getQuotes(): Promise<Quote[]>;
  getRandomQuote(): Promise<Quote | undefined>;
  createQuote(quote: InsertQuote): Promise<Quote>;
  
  // Premium routines methods
  getPremiumRoutines(): Promise<PremiumRoutine[]>;
  getPremiumRoutineById(id: number): Promise<PremiumRoutine | undefined>;
  createPremiumRoutine(routine: InsertPremiumRoutine): Promise<PremiumRoutine>;
  unlockPremiumRoutine(userId: number, routineId: number): Promise<boolean>;
  getUserPremiumRoutines(userId: number): Promise<PremiumRoutine[]>;
  
  // Video methods
  getVideos(category?: string): Promise<Video[]>;
  getVideoById(id: number): Promise<Video | undefined>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideoLikes(id: number, likes: number): Promise<Video | undefined>;
  updateVideoViews(id: number, views: number): Promise<Video | undefined>;
  deleteVideo(id: number): Promise<boolean>;
  
  // Video comments methods
  getVideoComments(videoId: number): Promise<VideoComment[]>;
  createVideoComment(comment: InsertVideoComment): Promise<VideoComment>;
  deleteVideoComment(id: number): Promise<boolean>;
  
  // Announcement methods
  getAnnouncements(type?: string): Promise<Announcement[]>;
  getActiveAnnouncements(): Promise<Announcement[]>; 
  getAnnouncementById(id: number): Promise<Announcement | undefined>;
  createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement>;
  updateAnnouncement(id: number, announcement: Partial<InsertAnnouncement>): Promise<Announcement | undefined>;
  deleteAnnouncement(id: number): Promise<boolean>;
  
  // Level and XP methods
  updateUserXP(userId: number, xp: number, xpTotal: number): Promise<User>;
  updateUserLevelName(userId: number, levelName: string): Promise<User>;
  checkLevelUpEligibility(userId: number): Promise<{leveledUp: boolean, newLevel?: number, rewards?: string}>;
  
  // Challenge methods
  getChallenges(category?: string): Promise<Challenge[]>;
  getActiveChallenges(): Promise<Challenge[]>;
  getChallengeById(id: number): Promise<Challenge | undefined>;
  createChallenge(challenge: InsertChallenge): Promise<Challenge>;
  updateChallenge(id: number, challenge: Partial<InsertChallenge>): Promise<Challenge | undefined>;
  incrementChallengeCompletions(id: number): Promise<Challenge | undefined>;
  deleteChallenge(id: number): Promise<boolean>;
  
  // User challenge methods
  getUserChallenges(userId: number): Promise<UserChallenge[]>;
  getUserChallengeById(id: number): Promise<UserChallenge | undefined>;
  joinChallenge(userId: number, challengeId: number): Promise<UserChallenge>;
  updateUserChallengeProgress(id: number, progress: number): Promise<UserChallenge | undefined>;
  completeUserChallenge(id: number): Promise<UserChallenge | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const results = await db.select().from(users).where(eq(users.id, id));
    return results[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const results = await db.select().from(users).where(eq(users.username, username));
    return results[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const results = await db.insert(users).values({
      ...user,
      level: 1,
      levelProgress: 0,
      currentStreak: 0,
      coins: 50 // Start with 50 coins
    }).returning();
    return results[0];
  }
  
  async updateUserStreak(userId: number, streak: number): Promise<User> {
    const results = await db.update(users)
      .set({ currentStreak: streak })
      .where(eq(users.id, userId))
      .returning();
    
    if (results.length === 0) {
      throw new Error(`User with id ${userId} not found`);
    }
    
    return results[0];
  }
  
  async updateUserLevel(userId: number, level: number, progress: number): Promise<User> {
    const results = await db.update(users)
      .set({ level, levelProgress: progress })
      .where(eq(users.id, userId))
      .returning();
    
    if (results.length === 0) {
      throw new Error(`User with id ${userId} not found`);
    }
    
    return results[0];
  }

  // Task methods
  async getTasks(userId: number): Promise<Task[]> {
    return db.select().from(tasks).where(eq(tasks.userId, userId));
  }

  async getTaskById(id: number): Promise<Task | undefined> {
    const results = await db.select().from(tasks).where(eq(tasks.id, id));
    return results[0];
  }

  async createTask(task: InsertTask): Promise<Task> {
    const results = await db.insert(tasks).values(task).returning();
    return results[0];
  }

  async updateTask(id: number, taskUpdate: Partial<InsertTask>): Promise<Task | undefined> {
    const results = await db.update(tasks)
      .set(taskUpdate)
      .where(eq(tasks.id, id))
      .returning();
    
    return results[0];
  }

  async completeTask(id: number, completed: boolean): Promise<Task | undefined> {
    const results = await db.update(tasks)
      .set({ completed })
      .where(eq(tasks.id, id))
      .returning();
    
    return results[0];
  }

  async deleteTask(id: number): Promise<boolean> {
    const result = await db.delete(tasks).where(eq(tasks.id, id));
    return true; // In PostgreSQL, if the record doesn't exist, it won't throw an error
  }

  // Habit methods
  async getHabits(userId: number): Promise<Habit[]> {
    return db.select().from(habits).where(eq(habits.userId, userId));
  }

  async getHabitById(id: number): Promise<Habit | undefined> {
    const results = await db.select().from(habits).where(eq(habits.id, id));
    return results[0];
  }

  async createHabit(habit: InsertHabit): Promise<Habit> {
    const results = await db.insert(habits).values({
      ...habit,
      streak: 0
    }).returning();
    return results[0];
  }

  async updateHabit(id: number, habitUpdate: Partial<InsertHabit>): Promise<Habit | undefined> {
    const results = await db.update(habits)
      .set(habitUpdate)
      .where(eq(habits.id, id))
      .returning();
    
    return results[0];
  }

  async updateHabitStreak(id: number, streak: number): Promise<Habit | undefined> {
    const results = await db.update(habits)
      .set({ streak })
      .where(eq(habits.id, id))
      .returning();
    
    return results[0];
  }

  async deleteHabit(id: number): Promise<boolean> {
    // Delete all completions for this habit first
    await db.delete(habitCompletions).where(eq(habitCompletions.habitId, id));
    
    // Then delete the habit
    await db.delete(habits).where(eq(habits.id, id));
    return true;
  }

  // Habit completion methods
  async getHabitCompletions(habitId: number): Promise<HabitCompletion[]> {
    return db.select()
      .from(habitCompletions)
      .where(eq(habitCompletions.habitId, habitId));
  }

  async createHabitCompletion(completion: InsertHabitCompletion): Promise<HabitCompletion> {
    const results = await db.insert(habitCompletions)
      .values(completion)
      .returning();
    return results[0];
  }

  async getHabitCompletionsForDate(habitId: number, date: Date): Promise<HabitCompletion[]> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);
    
    return db.select()
      .from(habitCompletions)
      .where(
        and(
          eq(habitCompletions.habitId, habitId),
          between(habitCompletions.completedDate, startOfDay, endOfDay)
        )
      );
  }

  // Routine methods
  async getRoutineItems(userId: number): Promise<RoutineItem[]> {
    return db.select()
      .from(routineItems)
      .where(eq(routineItems.userId, userId))
      .orderBy(routineItems.order);
  }

  async getRoutineItemById(id: number): Promise<RoutineItem | undefined> {
    const results = await db.select()
      .from(routineItems)
      .where(eq(routineItems.id, id));
    return results[0];
  }

  async createRoutineItem(item: InsertRoutineItem): Promise<RoutineItem> {
    const results = await db.insert(routineItems)
      .values(item)
      .returning();
    return results[0];
  }

  async updateRoutineItem(id: number, itemUpdate: Partial<InsertRoutineItem>): Promise<RoutineItem | undefined> {
    const results = await db.update(routineItems)
      .set(itemUpdate)
      .where(eq(routineItems.id, id))
      .returning();
    
    return results[0];
  }

  async deleteRoutineItem(id: number): Promise<boolean> {
    await db.delete(routineItems).where(eq(routineItems.id, id));
    return true;
  }

  // Quote methods
  async getQuotes(): Promise<Quote[]> {
    return db.select().from(quotes);
  }

  async getRandomQuote(): Promise<Quote | undefined> {
    // Use PostgreSQL's RANDOM() function to get a random quote
    const results = await db.select()
      .from(quotes)
      .orderBy(sql`RANDOM()`)
      .limit(1);
    
    return results[0];
  }

  async createQuote(quote: InsertQuote): Promise<Quote> {
    const results = await db.insert(quotes)
      .values(quote)
      .returning();
    return results[0];
  }

  // Premium routines methods
  async getPremiumRoutines(): Promise<PremiumRoutine[]> {
    return db.select().from(premiumRoutines);
  }

  async getPremiumRoutineById(id: number): Promise<PremiumRoutine | undefined> {
    const results = await db.select().from(premiumRoutines).where(eq(premiumRoutines.id, id));
    return results[0];
  }

  async createPremiumRoutine(routine: InsertPremiumRoutine): Promise<PremiumRoutine> {
    const results = await db.insert(premiumRoutines).values(routine).returning();
    return results[0];
  }

  async unlockPremiumRoutine(userId: number, routineId: number): Promise<boolean> {
    // First check if the user has enough coins
    const userResult = await this.getUser(userId);
    if (!userResult) {
      throw new Error(`User with id ${userId} not found`);
    }

    // Get the routine cost
    const routineResult = await this.getPremiumRoutineById(routineId);
    if (!routineResult) {
      throw new Error(`Premium routine with id ${routineId} not found`);
    }

    // Check if user already unlocked this routine
    const existingUnlocks = await db.select()
      .from(userPremiumRoutines)
      .where(
        and(
          eq(userPremiumRoutines.userId, userId),
          eq(userPremiumRoutines.routineId, routineId)
        )
      );
    
    if (existingUnlocks.length > 0) {
      return true; // Already unlocked
    }

    // Check if user has enough coins
    if (userResult.coins < routineResult.cost) {
      throw new Error(`User does not have enough coins to unlock this routine. Required: ${routineResult.cost}, User has: ${userResult.coins}`);
    }

    // Deduct coins from user
    await this.updateUserCoins(userId, userResult.coins - routineResult.cost);

    // Create unlock record
    await db.insert(userPremiumRoutines)
      .values({
        userId,
        routineId
      });

    return true;
  }

  async getUserPremiumRoutines(userId: number): Promise<PremiumRoutine[]> {
    // Get IDs of routines the user has unlocked
    const unlockedRoutines = await db.select({ routineId: userPremiumRoutines.routineId })
      .from(userPremiumRoutines)
      .where(eq(userPremiumRoutines.userId, userId));
    
    if (unlockedRoutines.length === 0) {
      return []; // No routines unlocked yet
    }
    
    // Get routine details
    const routineIds = unlockedRoutines.map(r => r.routineId);
    return db.select()
      .from(premiumRoutines)
      .where(inArray(premiumRoutines.id, routineIds));
  }

  async updateUserCoins(userId: number, coins: number): Promise<User> {
    const results = await db.update(users)
      .set({ coins })
      .where(eq(users.id, userId))
      .returning();
    
    if (results.length === 0) {
      throw new Error(`User with id ${userId} not found`);
    }
    
    return results[0];
  }

  // Video methods
  async getVideos(category?: string): Promise<Video[]> {
    if (category) {
      return db.select()
        .from(videos)
        .where(eq(videos.category, category as any))
        .orderBy(desc(videos.createdAt));
    }
    
    return db.select()
      .from(videos)
      .orderBy(desc(videos.createdAt));
  }

  async getVideoById(id: number): Promise<Video | undefined> {
    const results = await db.select().from(videos).where(eq(videos.id, id));
    return results[0];
  }

  async createVideo(video: InsertVideo): Promise<Video> {
    const results = await db.insert(videos)
      .values({
        ...video,
        views: 0,
        likes: 0,
        createdAt: new Date()
      })
      .returning();
    return results[0];
  }

  async updateVideoLikes(id: number, likes: number): Promise<Video | undefined> {
    const results = await db.update(videos)
      .set({ likes })
      .where(eq(videos.id, id))
      .returning();
    
    return results[0];
  }

  async updateVideoViews(id: number, views: number): Promise<Video | undefined> {
    const results = await db.update(videos)
      .set({ views })
      .where(eq(videos.id, id))
      .returning();
    
    return results[0];
  }

  async deleteVideo(id: number): Promise<boolean> {
    // Delete all comments for this video first
    await db.delete(videoComments).where(eq(videoComments.videoId, id));
    
    // Then delete the video
    await db.delete(videos).where(eq(videos.id, id));
    return true;
  }

  // Video comment methods
  async getVideoComments(videoId: number): Promise<VideoComment[]> {
    return db.select()
      .from(videoComments)
      .where(eq(videoComments.videoId, videoId))
      .orderBy(desc(videoComments.createdAt));
  }

  async createVideoComment(comment: InsertVideoComment): Promise<VideoComment> {
    const results = await db.insert(videoComments)
      .values({
        ...comment,
        createdAt: new Date()
      })
      .returning();
    return results[0];
  }

  async deleteVideoComment(id: number): Promise<boolean> {
    await db.delete(videoComments).where(eq(videoComments.id, id));
    return true;
  }
  
  // Announcement methods
  async getAnnouncements(type?: string): Promise<Announcement[]> {
    if (type) {
      return db.select()
        .from(announcements)
        .where(eq(announcements.type, type))
        .orderBy(desc(announcements.createdAt));
    }
    
    return db.select()
      .from(announcements)
      .orderBy(desc(announcements.createdAt));
  }
  
  async getActiveAnnouncements(): Promise<Announcement[]> {
    return db.select()
      .from(announcements)
      .where(eq(announcements.isActive, true))
      .orderBy(announcements.isPinned, desc(announcements.createdAt));
  }
  
  async getAnnouncementById(id: number): Promise<Announcement | undefined> {
    const results = await db.select().from(announcements).where(eq(announcements.id, id));
    return results[0];
  }
  
  async createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement> {
    const results = await db.insert(announcements)
      .values({
        ...announcement,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return results[0];
  }
  
  async updateAnnouncement(id: number, announcementUpdate: Partial<InsertAnnouncement>): Promise<Announcement | undefined> {
    const results = await db.update(announcements)
      .set({
        ...announcementUpdate,
        updatedAt: new Date()
      })
      .where(eq(announcements.id, id))
      .returning();
    
    return results[0];
  }
  
  async deleteAnnouncement(id: number): Promise<boolean> {
    await db.delete(announcements).where(eq(announcements.id, id));
    return true;
  }
  
  // Level and XP methods
  async updateUserXP(userId: number, xp: number, xpTotal: number): Promise<User> {
    const results = await db.update(users)
      .set({ xp, xpTotal })
      .where(eq(users.id, userId))
      .returning();
    
    if (results.length === 0) {
      throw new Error(`User with id ${userId} not found`);
    }
    
    return results[0];
  }
  
  async updateUserLevelName(userId: number, levelName: string): Promise<User> {
    const results = await db.update(users)
      .set({ 
        levelName: levelName as any,
        lastLevelUp: new Date()
      })
      .where(eq(users.id, userId))
      .returning();
    
    if (results.length === 0) {
      throw new Error(`User with id ${userId} not found`);
    }
    
    return results[0];
  }
  
  async checkLevelUpEligibility(userId: number): Promise<{leveledUp: boolean, newLevel?: number, rewards?: string}> {
    const userResult = await this.getUser(userId);
    if (!userResult) {
      throw new Error(`User with id ${userId} not found`);
    }
    
    // Check current XP against required XP for next level
    const currentLevel = userResult.level;
    
    // Don't level up if user is already at max level (6)
    if (currentLevel >= 6) {
      return { leveledUp: false };
    }
    
    const nextLevel = currentLevel + 1;
    const requiredXP = LevelInfo[nextLevel as keyof typeof LevelInfo].xpNeeded;
    
    if (userResult.xpTotal >= requiredXP) {
      // User can level up!
      await db.update(users)
        .set({ 
          level: nextLevel,
          levelName: LevelNames[`LEVEL_${nextLevel}` as keyof typeof LevelNames] || LevelNames.INITIATE_G,
          lastLevelUp: new Date()
        })
        .where(eq(users.id, userId));
      
      const rewards = LevelInfo[nextLevel as keyof typeof LevelInfo].rewards;
      
      return { 
        leveledUp: true, 
        newLevel: nextLevel,
        rewards
      };
    }
    
    return { leveledUp: false };
  }
  
  // Challenge methods
  async getChallenges(category?: string): Promise<Challenge[]> {
    if (category) {
      return db.select()
        .from(challenges)
        .where(eq(challenges.category, category as any))
        .orderBy(desc(challenges.startDate));
    }
    
    return db.select()
      .from(challenges)
      .orderBy(desc(challenges.startDate));
  }
  
  async getActiveChallenges(): Promise<Challenge[]> {
    const now = new Date();
    
    return db.select()
      .from(challenges)
      .where(
        and(
          eq(challenges.isActive, true),
          sql`${challenges.startDate} <= ${now} AND ${challenges.endDate} >= ${now}`
        )
      )
      .orderBy(challenges.endDate);
  }
  
  async getChallengeById(id: number): Promise<Challenge | undefined> {
    const results = await db.select().from(challenges).where(eq(challenges.id, id));
    return results[0];
  }
  
  async createChallenge(challenge: InsertChallenge): Promise<Challenge> {
    const results = await db.insert(challenges)
      .values({
        ...challenge,
        completedCount: 0,
        createdAt: new Date()
      })
      .returning();
    return results[0];
  }
  
  async updateChallenge(id: number, challengeUpdate: Partial<InsertChallenge>): Promise<Challenge | undefined> {
    const results = await db.update(challenges)
      .set(challengeUpdate)
      .where(eq(challenges.id, id))
      .returning();
    
    return results[0];
  }
  
  async incrementChallengeCompletions(id: number): Promise<Challenge | undefined> {
    const challenge = await this.getChallengeById(id);
    if (!challenge) {
      return undefined;
    }
    
    const results = await db.update(challenges)
      .set({ 
        completedCount: (challenge.completedCount || 0) + 1
      })
      .where(eq(challenges.id, id))
      .returning();
    
    return results[0];
  }
  
  async deleteChallenge(id: number): Promise<boolean> {
    // Delete all user participations first
    await db.delete(userChallenges).where(eq(userChallenges.challengeId, id));
    
    // Then delete the challenge
    await db.delete(challenges).where(eq(challenges.id, id));
    return true;
  }
  
  // User challenge methods
  async getUserChallenges(userId: number): Promise<UserChallenge[]> {
    return db.select()
      .from(userChallenges)
      .where(eq(userChallenges.userId, userId))
      .orderBy(desc(userChallenges.joinedAt));
  }
  
  async getUserChallengeById(id: number): Promise<UserChallenge | undefined> {
    const results = await db.select().from(userChallenges).where(eq(userChallenges.id, id));
    return results[0];
  }
  
  async joinChallenge(userId: number, challengeId: number): Promise<UserChallenge> {
    // Check if user already joined this challenge
    const existingJoins = await db.select()
      .from(userChallenges)
      .where(
        and(
          eq(userChallenges.userId, userId),
          eq(userChallenges.challengeId, challengeId)
        )
      );
    
    if (existingJoins.length > 0) {
      return existingJoins[0]; // Already joined
    }
    
    // Get the challenge to check if user can join (based on required level)
    const challenge = await this.getChallengeById(challengeId);
    if (!challenge) {
      throw new Error(`Challenge with id ${challengeId} not found`);
    }
    
    // Check user level
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error(`User with id ${userId} not found`);
    }
    
    if (user.level < challenge.requiredLevel) {
      throw new Error(`User level (${user.level}) is below the required level (${challenge.requiredLevel}) for this challenge`);
    }
    
    // Create join record
    const results = await db.insert(userChallenges)
      .values({
        userId,
        challengeId,
        progress: 0,
        isCompleted: false,
        joinedAt: new Date()
      })
      .returning();
    
    return results[0];
  }
  
  async updateUserChallengeProgress(id: number, progress: number): Promise<UserChallenge | undefined> {
    const userChallenge = await this.getUserChallengeById(id);
    if (!userChallenge) {
      return undefined;
    }
    
    // Get the challenge to check target
    const challenge = await this.getChallengeById(userChallenge.challengeId);
    if (!challenge) {
      throw new Error(`Challenge with id ${userChallenge.challengeId} not found`);
    }
    
    // Check if the progress meets the target (challenge completed)
    const isCompleted = progress >= challenge.target;
    let completedAt = userChallenge.completedAt;
    
    // If completed for the first time, set the completedAt date and give rewards
    if (isCompleted && !userChallenge.isCompleted) {
      completedAt = new Date();
      
      // Give rewards to user
      const user = await this.getUser(userChallenge.userId);
      if (user) {
        // Update XP
        await this.updateUserXP(
          user.id, 
          user.xp + challenge.xpReward,
          user.xpTotal + challenge.xpReward
        );
        
        // Update coins if there's a coin reward
        if (challenge.coinReward > 0) {
          await this.updateUserCoins(user.id, user.coins + challenge.coinReward);
        }
        
        // Update challenge completion count
        await this.incrementChallengeCompletions(challenge.id);
      }
    }
    
    const results = await db.update(userChallenges)
      .set({ 
        progress,
        isCompleted,
        completedAt
      })
      .where(eq(userChallenges.id, id))
      .returning();
    
    return results[0];
  }
  
  async completeUserChallenge(id: number): Promise<UserChallenge | undefined> {
    const userChallenge = await this.getUserChallengeById(id);
    if (!userChallenge) {
      return undefined;
    }
    
    // Get the challenge to get target
    const challenge = await this.getChallengeById(userChallenge.challengeId);
    if (!challenge) {
      throw new Error(`Challenge with id ${userChallenge.challengeId} not found`);
    }
    
    // Force complete the challenge by setting progress to target
    return this.updateUserChallengeProgress(id, challenge.target);
  }

  // Helper to seed initial data
  async seedInitialData() {
    // Check if we already have users
    const existingUsers = await db.select().from(users);
    if (existingUsers.length > 0) {
      console.log("Database already contains data, skipping seed");
      return;
    }

    console.log("Seeding initial data...");

    // Create default user
    const user = await this.createUser({
      username: "topg",
      password: "password123"
    });

    // Create default quotes
    await this.createQuote({
      text: "You have the potential to be worth millions. Wake up early, work hard, make sacrifices.",
      author: "Andrew Tate"
    });
    
    await this.createQuote({
      text: "The temporary satisfaction of quitting is outweighed by the eternal suffering of being a nobody.",
      author: "Andrew Tate"
    });
    
    await this.createQuote({
      text: "Success is not a straight line. You will fail and fail until you succeed.",
      author: "Andrew Tate"
    });
    
    await this.createQuote({
      text: "Discipline equals freedom. The harder you work, the freer you become.",
      author: "Andrew Tate"
    });
    
    await this.createQuote({
      text: "Champions have a champion's mindset. They control their thoughts, they control their life.",
      author: "Andrew Tate"
    });

    // Create default routine
    await this.createRoutineItem({
      userId: user.id,
      time: "5:00 AM",
      activity: "Wake Up",
      description: "Start the day before everyone else",
      category: RoutineCategories.DISCIPLINE,
      order: 1
    });
    
    await this.createRoutineItem({
      userId: user.id,
      time: "5:15 AM",
      activity: "Cold Shower",
      description: "Strengthen your mind and immune system",
      category: RoutineCategories.HEALTH,
      order: 2
    });
    
    await this.createRoutineItem({
      userId: user.id,
      time: "6:00 AM",
      activity: "Morning Workout",
      description: "Intensive cardio and strength training",
      category: RoutineCategories.FITNESS,
      order: 3
    });
    
    await this.createRoutineItem({
      userId: user.id,
      time: "7:30 AM",
      activity: "Meditation",
      description: "Clear your mind and focus on goals",
      category: RoutineCategories.MINDSET,
      order: 4
    });
    
    await this.createRoutineItem({
      userId: user.id,
      time: "8:00 AM",
      activity: "Business Work",
      description: "Focus on high-value business activities",
      category: RoutineCategories.WORK,
      order: 5
    });

    // Create default premium routines
    await this.createPremiumRoutine({
      title: "500 Push-ups Challenge",
      description: "Advanced chest workout for building massive upper body strength",
      cost: 50,
      details: "Complete 500 push-ups daily for 30 days to build extreme upper body strength. Start with sets of 50 and work your way up.",
      isLocked: true
    });

    await this.createPremiumRoutine({
      title: "3 Litre Water Challenge",
      description: "Hydration protocol for optimal health and performance",
      cost: 30,
      details: "Drink 3 litres of water daily, properly spaced throughout the day for maximum absorption and cellular hydration.",
      isLocked: true
    });

    await this.createPremiumRoutine({
      title: "5 KM Daily Run",
      description: "Cardio protocol for mental and physical toughness",
      cost: 40,
      details: "Complete a 5 KM run daily before breakfast to boost metabolism and build mental strength. Focus on improving time each day.",
      isLocked: true
    });

    // Create initial videos
    await this.createVideo({
      userId: user.id,
      title: "The 5 Morning Habits of Elite Performers",
      description: "In this short clip, I discuss the essential morning routine that separates winners from losers. Wake up and implement these 5 habits immediately.",
      category: VideoCategories.TATE_SHORT,
      thumbnailUrl: "https://i.imgur.com/JYkFGEw.jpg",
      url: "https://example.com/videos/morning-habits.mp4"
    });

    await this.createVideo({
      userId: user.id,
      title: "How I Made My First Million",
      description: "The complete breakdown of my journey from broke to millionaire. I show exactly how I did it and how you can too.",
      category: VideoCategories.TATE_LONG,
      thumbnailUrl: "https://i.imgur.com/R6YPtpB.jpg",
      url: "https://example.com/videos/first-million.mp4"
    });

    await this.createVideo({
      userId: user.id,
      title: "The Matrix Has You",
      description: "Short clip on how the modern world is designed to keep you poor, weak and distracted. Time to break free.",
      category: VideoCategories.TATE_SHORT,
      thumbnailUrl: "https://i.imgur.com/A7LQMmR.jpg",
      url: "https://example.com/videos/matrix.mp4"
    });

    await this.createVideo({
      userId: user.id,
      title: "Passive Income Masterclass",
      description: "Learn the exact blueprint I use to create multiple streams of income that make money while I sleep.",
      category: VideoCategories.TATE_LONG,
      thumbnailUrl: "https://i.imgur.com/ZQDXr7H.jpg",
      url: "https://example.com/videos/passive-income.mp4"
    });

    await this.createVideo({
      userId: user.id,
      title: "Mindset of Champions",
      description: "Your mind is your most powerful weapon. In this podcast, I break down the psychological traits of winners.",
      category: VideoCategories.TATE_PODCAST,
      thumbnailUrl: "https://i.imgur.com/P0MsH3L.jpg",
      url: "https://example.com/videos/champion-mindset.mp4"
    });
    
    // Create initial announcements
    await this.createAnnouncement({
      title: "Welcome to Top G Lifestyle",
      content: "This is the official platform for those who want to live the Top G lifestyle. Stay tuned for exclusive content and updates.",
      type: AnnouncementTypes.GENERAL,
      isActive: true,
      isPinned: true
    });
    
    await this.createAnnouncement({
      title: "Join Our Team",
      content: "We are looking for dedicated individuals to join our team. If you have skills in social media management, content creation, or marketing, send your application now!",
      type: AnnouncementTypes.HIRING,
      isActive: true,
      isPinned: false
    });
    
    await this.createAnnouncement({
      title: "New Features Coming Soon",
      content: "We are working on exciting new features including live streams, direct messaging with coaches, and customized workout plans. Stay tuned!",
      type: AnnouncementTypes.UPDATE,
      isActive: true,
      isPinned: false
    });

    // Create initial community challenges
    await this.createChallenge({
      title: "30-Day Cold Shower",
      description: "Take cold showers every morning for 30 days to build mental toughness and improve circulation.",
      category: ChallengeCategories.DAILY,
      startDate: new Date(),
      endDate: new Date(new Date().setDate(new Date().getDate() + 30)),
      target: 30,
      isActive: true,
      xpReward: 1000,
      coinReward: 100,
      requiredLevel: 1,
      imageUrl: "https://i.imgur.com/example1.jpg"
    });
    
    await this.createChallenge({
      title: "No Excuses Workout",
      description: "Complete a workout every single day for 14 days, no matter what.",
      category: ChallengeCategories.DAILY,
      startDate: new Date(),
      endDate: new Date(new Date().setDate(new Date().getDate() + 14)),
      target: 14,
      isActive: true,
      xpReward: 500,
      coinReward: 50,
      requiredLevel: 1,
      imageUrl: "https://i.imgur.com/example2.jpg"
    });
    
    await this.createChallenge({
      title: "5AM Club",
      description: "Wake up at 5AM for 21 days to take control of your mornings.",
      category: ChallengeCategories.DAILY,
      startDate: new Date(),
      endDate: new Date(new Date().setDate(new Date().getDate() + 21)),
      target: 21,
      isActive: true,
      xpReward: 750,
      coinReward: 75,
      requiredLevel: 2,
      imageUrl: "https://i.imgur.com/example3.jpg"
    });
    
    await this.createChallenge({
      title: "Digital Detox",
      description: "Limit social media to 30 minutes per day for 10 days.",
      category: ChallengeCategories.WEEKLY,
      startDate: new Date(),
      endDate: new Date(new Date().setDate(new Date().getDate() + 10)),
      target: 10,
      isActive: true,
      xpReward: 300,
      coinReward: 30,
      requiredLevel: 1,
      imageUrl: "https://i.imgur.com/example4.jpg"
    });
    
    await this.createChallenge({
      title: "Entrepreneur Challenge",
      description: "Work on your business idea for at least 2 hours every day for 30 days.",
      category: ChallengeCategories.COMMUNITY,
      startDate: new Date(),
      endDate: new Date(new Date().setDate(new Date().getDate() + 30)),
      target: 30,
      isActive: true,
      xpReward: 1500,
      coinReward: 150,
      requiredLevel: 3,
      imageUrl: "https://i.imgur.com/example5.jpg"
    });
    
    console.log("Initial data seeded successfully");
  }
}

// Initialize the database storage and export it
export const storage = new DatabaseStorage();
